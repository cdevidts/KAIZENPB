# Fila 7 + Fila 17 - Handover Comercial-Operaciones sin estándar de alcance

## Ficha Ejecutiva
- Filas combinadas: 7, 17
- Áreas involucradas: Comercial, Operaciones
- Importancia promedio: 4.0/5
- IBO combinado estimado: 80/100
- KAIZEN dominante: Transporte/Traspasos

## Descripción Combinada Propuesta
El traspaso de proyectos ganados no llega como paquete operativo accionable; Operaciones debe reinterpretar alcance y reconstruir estructura de ejecución, generando retrasos y conflictos evitables.

## Subproblemas Comunes
- OPS rehace Gantts y recopila manualmente
- “Que nos reporten un listado con los alcances que tenemos que cumplir”

## Cuello De Botella Transversal
- El flujo cruza más de un área con responsabilidades no estandarizadas, datos no interoperables y control tardío. Por eso aparecen síntomas distintos para el mismo problema estructural.

## Impacto Operacional Combinado
- Multiplica retrabajo entre áreas, aumenta tiempos de ciclo y reduce capacidad de anticipar desvíos de costo/plazo/calidad.
- Incrementa el riesgo de decisiones reactivas (urgencia) en lugar de gestión preventiva.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: handover inmediatamente posterior a adjudicación y previo al kickoff de ejecución.
- Stack tentativo: **SharePoint + Teams + Copilot en Word + Power Automate** con paquete estándar de alcance.
- Automatización: checklist de entrega, acta de alcances operativos y control de SLA de revisión por Operaciones.
- Licenciamiento foco: estandarización documental M365 para reducir fricción Comercial-Operaciones.
- Enfoque de despliegue recomendado: piloto cross-área por Wave de 90 días, con baseline y decisión Go/No-Go al cierre.

## Semáforo De Gravedad
- Color asignado: **Naranja Alto (#F57C00)**
- Base de asignación: promedio de importancia de filas combinadas **4.00/5**.
- Lectura ejecutiva: Impacto alto multiárea o en un proceso crítico de negocio.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Amarillo Implementación Corta (#F9A825)**
- Ventana tentativa: **5-8 semanas**
- Lectura ejecutiva: Requiere estandarización de proceso y automatizaciones moderadas.

## Recomendación De Formulación Única
- Definir un owner transversal del proceso (no por silo), una estructura de datos común y un único punto de verdad para seguimiento operativo-financiero.

## Trazabilidad
- Fila 7: Handover Comercial a OPS sin formato (desordenado y a goteo)
- Fila 17: Dificultad / sobretiempo en entender oferta comercial entregada por Comercial

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)