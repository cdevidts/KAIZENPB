# Fila 9 + Fila 14 + Fila 18 - Reportabilidad operativa manual y desvíos tardíos

## Ficha Ejecutiva
- Filas combinadas: 9, 14, 18
- Áreas involucradas: Operaciones
- Importancia promedio: 4.67/5
- IBO combinado estimado: 93/100
- KAIZEN dominante: Sobreprocesamiento

## Descripción Combinada Propuesta
La reportabilidad depende de consolidación manual de información heterogénea; esto degrada calidad de evidencia y retrasa la detección de desvíos con impacto contractual.

## Subproblemas Comunes
- Cruzar info sucedida con línea base, Curva S; consolidar reportes diarios a semanal y mensual
- Falta de herramientas para recopilar la info completa de los reportes (ej: explicaciones de desvíos en un correo)
- Falta de un formato estándar para reportes
- Deben revisar y corregir faltas antes de entregar a cliente
- Información crítica de desvíos dispersa en correos no estructurados (“No escrito no sirve”)
- Falta de agilidad en reportabilidad por falta de tiempo para control de cambio
- Dificultan identificación clave para extensiones de contratos
- Extensiones entorpecidas por temas de info del personal

## Cuello De Botella Transversal
- El flujo cruza más de un área con responsabilidades no estandarizadas, datos no interoperables y control tardío. Por eso aparecen síntomas distintos para el mismo problema estructural.

## Impacto Operacional Combinado
- Multiplica retrabajo entre áreas, aumenta tiempos de ciclo y reduce capacidad de anticipar desvíos de costo/plazo/calidad.
- Incrementa el riesgo de decisiones reactivas (urgencia) en lugar de gestión preventiva.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: desde reporte diario en terreno hasta reporte semanal y gestión de desvíos contractuales.
- Stack tentativo: **Power Apps + SharePoint + Power Automate + Copilot + Power BI**.
- Automatización: captura estructurada, consolidación automática, evidencias trazables y alertas de control de cambio/extensión.
- Licenciamiento foco: Power Platform y Copilot para disminuir HH manual de reportabilidad.
- Enfoque de despliegue recomendado: piloto cross-área por Wave de 90 días, con baseline y decisión Go/No-Go al cierre.

## Semáforo De Gravedad
- Color asignado: **Rojo Crítico (#D32F2F)**
- Base de asignación: promedio de importancia de filas combinadas **4.67/5**.
- Lectura ejecutiva: Impacto transversal sobre operación completa, margen y caja.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Naranja Implementación Media (#EF6C00)**
- Ventana tentativa: **9-12 semanas**
- Lectura ejecutiva: Integra múltiples componentes M365/Dynamics + UAT formal.

## Recomendación De Formulación Única
- Definir un owner transversal del proceso (no por silo), una estructura de datos común y un único punto de verdad para seguimiento operativo-financiero.

## Trazabilidad
- Fila 9: Reportabilidad manual intensiva
- Fila 14: Reportes diarios de terreno de mala calidad
- Fila 18: Visibilidad tardía de desvíos afecta oportunidades de extensión

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)