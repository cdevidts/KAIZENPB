# Fila 3 + Fila 12 - BOM con errores y compras manuales línea a línea

## Ficha Ejecutiva
- Filas combinadas: 3, 12
- Áreas involucradas: Ingeniería, Operaciones
- Importancia promedio: 4.5/5
- IBO combinado estimado: 90/100
- KAIZEN dominante: Defectos

## Descripción Combinada Propuesta
Baja calidad de datos técnicos (BOM/códigos/spares) combinada con proceso de compras manual por línea crea un ciclo de retrabajo costoso entre Ingeniería y Operaciones.

## Subproblemas Comunes
- Múltiples entradas/códigos para un mismo ítem (Difieren en descripción, unidad de medida, etc.)
- Revisar stock se entorpece (Distinto stock para dos códigos del mismo ítem)
- No hay proceso formal (o herramienta) de revisión / chequeo cruzado de BOMs
- Operaciones se hace cargo de las solicitudes de compra; deben ingresar uno a uno ítem por ítem
- Ingeniería envía BOMs que hay que revisar por errores de códigos de ítems
- BOMs sin “spares”
- Proceso no formalizado con etapa de validación de datos

## Cuello De Botella Transversal
- El flujo cruza más de un área con responsabilidades no estandarizadas, datos no interoperables y control tardío. Por eso aparecen síntomas distintos para el mismo problema estructural.

## Impacto Operacional Combinado
- Multiplica retrabajo entre áreas, aumenta tiempos de ciclo y reduce capacidad de anticipar desvíos de costo/plazo/calidad.
- Incrementa el riesgo de decisiones reactivas (urgencia) en lugar de gestión preventiva.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: validación BOM y transición directa a compra técnica.
- Stack tentativo: **Power Apps + Dataverse + Dynamics 365 F&O + Power Automate**.
- Automatización: detección de códigos duplicados/equivalencias, validación obligatoria y carga masiva de líneas de compra.
- Licenciamiento foco: conectividad con Dynamics y reglas de calidad de datos antes de compra.
- Enfoque de despliegue recomendado: piloto cross-área por Wave de 90 días, con baseline y decisión Go/No-Go al cierre.

## Semáforo De Gravedad
- Color asignado: **Rojo Crítico (#D32F2F)**
- Base de asignación: promedio de importancia de filas combinadas **4.50/5**.
- Lectura ejecutiva: Impacto transversal sobre operación completa, margen y caja.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Naranja Implementación Media (#EF6C00)**
- Ventana tentativa: **9-12 semanas**
- Lectura ejecutiva: Integra múltiples componentes M365/Dynamics + UAT formal.

## Recomendación De Formulación Única
- Definir un owner transversal del proceso (no por silo), una estructura de datos común y un único punto de verdad para seguimiento operativo-financiero.

## Trazabilidad
- Fila 3: Errores y sobrecostos BOM
- Fila 12: Solicitudes de compra muy manuales “uno a uno, línea por línea”

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)