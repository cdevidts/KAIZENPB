# Fila 2 + Fila 10 + Fila 13 + Fila 16 - Planificación no integrada, Shadow IT y vacío PMO

## Ficha Ejecutiva
- Filas combinadas: 2, 10, 13, 16
- Áreas involucradas: Ingeniería, Operaciones
- Importancia promedio: 4.5/5
- IBO combinado estimado: 90/100
- KAIZEN dominante: Talento no utilizado

## Descripción Combinada Propuesta
Problema transversal de planificación y control: la empresa opera con herramientas fragmentadas (Project local, Dynamics, BI), sin estándar corporativo de planificación colaborativa y sin una capacidad PMO madura que absorba gobierno metodológico.

## Subproblemas Comunes
- Uso excesivo de Excel manual para hacer la comparativa y juntar la data (Data en constante cambio → limita eficiencia)
- Dynamics orientado a uso y carga de datos, no a visualización ni análisis.
- Ingeniería visualiza desvíos después de que sucedieron y no tiene claro cómo Operaciones lleva el cronograma hasta reportes. (Cada JP a su pinta, sin información cruzada en vivo con otras áreas por project local)
- Shadow IT. Licencias Project individuales e imposibilidad de entrelazar planillas.
- Antes había PMO (Project Management Office) que absorbía carga de recopilar y reportar. Hoy se cubre con trabajo manual extra.
- Prioridades y tareas cambian día a día y “no hay tiempo”
- Muchas veces predecesores no conectados fuerzan sobretrabajo en Gantt
- Poco detalle en Gantt de Comercial (rigurosidad en etapas/tareas)
- Projects (.mpp) no colaborativos
- Uso de IA tipo Chat Gpt, utilizando info de la empresa, pagada por trabajadores
- Actualización de Gantt deja de estar centralizada (antes lo hacía PMO/Planner)

## Cuello De Botella Transversal
- El flujo cruza más de un área con responsabilidades no estandarizadas, datos no interoperables y control tardío. Por eso aparecen síntomas distintos para el mismo problema estructural.

## Impacto Operacional Combinado
- Multiplica retrabajo entre áreas, aumenta tiempos de ciclo y reduce capacidad de anticipar desvíos de costo/plazo/calidad.
- Incrementa el riesgo de decisiones reactivas (urgencia) en lugar de gestión preventiva.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: desde preventa hasta control semanal de ejecución, unificando planificación corporativa.
- Stack tentativo: **Project Plan 3 + Dynamics 365 + Power BI + gobierno PMO-lite** sobre arquitectura M365-first.
- Automatización: baseline única, sincronización de avance/HH, alertas de ruta crítica y control de desvíos en tablero único.
- Licenciamiento foco: formalizar licencias corporativas (eliminar Shadow IT) y definir owner transversal del proceso.
- Enfoque de despliegue recomendado: piloto cross-área por Wave de 90 días, con baseline y decisión Go/No-Go al cierre.

## Semáforo De Gravedad
- Color asignado: **Rojo Crítico (#D32F2F)**
- Base de asignación: promedio de importancia de filas combinadas **4.50/5**.
- Lectura ejecutiva: Impacto transversal sobre operación completa, margen y caja.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Rojo Implementación Extendida (#C62828)**
- Ventana tentativa: **13-20 semanas**
- Lectura ejecutiva: Cambio estructural multiárea con integración profunda y gestión del cambio.

## Recomendación De Formulación Única
- Definir un owner transversal del proceso (no por silo), una estructura de datos común y un único punto de verdad para seguimiento operativo-financiero.

## Trazabilidad
- Fila 2: 1. Project (planificado: Gantt, asignaciones, horas, línea base) vs. Dynamics (carga HH, aprobación HH por JP, HH como registro contable, dato real ocurrido) vs. BI (horas consumidas por proyecto y por período, después de que ocurrieron) → No hay enlace entre la data (Planificado vs. real, trazabilidad, silo de información, sin integración automática)
- Fila 10: Gantt de Comercial no aterrizado a la operación (lo vendido por lo general se rearma al iniciar el proyecto; *preguntar por mejoras*)
- Fila 13: Shadow IT – Licencias Project (licencias auto pagadas)
- Fila 16: Tareas de PMO (antes Planner) para actualizar Gantt pasaron a ser responsabilidad de JP

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)