# Fila 6 + Fila 11 - Gobernanza débil de HH/costos desde preventa hasta ETC

## Ficha Ejecutiva
- Filas combinadas: 6, 11
- Áreas involucradas: Comercial, Operaciones
- Importancia promedio: 4.0/5
- IBO combinado estimado: 80/100
- KAIZEN dominante: Defectos

## Descripción Combinada Propuesta
No existe una gobernanza de punta a punta para HH/costos entre estimación comercial y control de ejecución, lo que obliga a reconstrucciones tardías en ETC y erosiona control financiero.

## Subproblemas Comunes
- Coordinación informal
- Ingeniería y OPS corrigen en operación (cambios circunstanciales)
- Sugiere sistematización con prueba y error
- JP deben buscar información en distintas fuentes
- Retrasos en proyección de gastos

## Cuello De Botella Transversal
- El flujo cruza más de un área con responsabilidades no estandarizadas, datos no interoperables y control tardío. Por eso aparecen síntomas distintos para el mismo problema estructural.

## Impacto Operacional Combinado
- Multiplica retrabajo entre áreas, aumenta tiempos de ciclo y reduce capacidad de anticipar desvíos de costo/plazo/calidad.
- Incrementa el riesgo de decisiones reactivas (urgencia) en lugar de gestión preventiva.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: desde validación HH de preventa hasta forecast de ETC en operación.
- Stack tentativo: **Dynamics 365 + Teams Approvals + Power BI + Power Automate**.
- Automatización: gate de validación HH por umbral, trazabilidad de aprobaciones y tablero de variación estimado vs consumido.
- Licenciamiento foco: gobernanza financiera-operativa de punta a punta con datos consistentes.
- Enfoque de despliegue recomendado: piloto cross-área por Wave de 90 días, con baseline y decisión Go/No-Go al cierre.

## Semáforo De Gravedad
- Color asignado: **Naranja Alto (#F57C00)**
- Base de asignación: promedio de importancia de filas combinadas **4.00/5**.
- Lectura ejecutiva: Impacto alto multiárea o en un proceso crítico de negocio.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Naranja Implementación Media (#EF6C00)**
- Ventana tentativa: **9-12 semanas**
- Lectura ejecutiva: Integra múltiples componentes M365/Dynamics + UAT formal.

## Recomendación De Formulación Única
- Definir un owner transversal del proceso (no por silo), una estructura de datos común y un único punto de verdad para seguimiento operativo-financiero.

## Trazabilidad
- Fila 6: Inexistencia protocolo formal validación HH con Ingeniería
- Fila 11: Torpeza en reportabilidad de facturación entorpece ETC

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)