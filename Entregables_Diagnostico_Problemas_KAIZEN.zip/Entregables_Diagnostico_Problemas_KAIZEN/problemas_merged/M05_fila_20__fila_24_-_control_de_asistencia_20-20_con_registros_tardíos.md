# Fila 20 + Fila 24 - Control de asistencia 20-20 con registros tardíos

## Ficha Ejecutiva
- Filas combinadas: 20, 24
- Áreas involucradas: Recursos Humanos
- Importancia promedio: 4.0/5
- IBO combinado estimado: 80/100
- KAIZEN dominante: Defectos

## Descripción Combinada Propuesta
El cierre 20-20 se apoya en entradas manuales tardías e inconsistentes, disminuyendo confiabilidad de asistencia y elevando retrabajo de RRHH en cada ciclo mensual.

## Subproblemas Comunes
- Hecho por JP; llega a RRHH con feriados faltantes, mal cálculo de horas extra e inconsistencias
- Deben corregir con libro de asistencia escaneado
- No se llenan día a día ordenadamente. Los llenan el día 20 a la rápida.

## Cuello De Botella Transversal
- El flujo cruza más de un área con responsabilidades no estandarizadas, datos no interoperables y control tardío. Por eso aparecen síntomas distintos para el mismo problema estructural.

## Impacto Operacional Combinado
- Multiplica retrabajo entre áreas, aumenta tiempos de ciclo y reduce capacidad de anticipar desvíos de costo/plazo/calidad.
- Incrementa el riesgo de decisiones reactivas (urgencia) en lugar de gestión preventiva.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: captura diaria de asistencia y consolidación de corte 20-20.
- Stack tentativo: **Power Apps móvil + Power Automate + Power BI RRHH**.
- Automatización: validaciones en origen, consolidado automático de corte y trazabilidad de ajustes.
- Licenciamiento foco: digitalizar asistencia y reducir reproceso mensual de RRHH.
- Enfoque de despliegue recomendado: piloto cross-área por Wave de 90 días, con baseline y decisión Go/No-Go al cierre.

## Semáforo De Gravedad
- Color asignado: **Naranja Alto (#F57C00)**
- Base de asignación: promedio de importancia de filas combinadas **4.00/5**.
- Lectura ejecutiva: Impacto alto multiárea o en un proceso crítico de negocio.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Amarillo Implementación Corta (#F9A825)**
- Ventana tentativa: **5-8 semanas**
- Lectura ejecutiva: Requiere estandarización de proceso y automatizaciones moderadas.

## Recomendación De Formulación Única
- Definir un owner transversal del proceso (no por silo), una estructura de datos común y un único punto de verdad para seguimiento operativo-financiero.

## Trazabilidad
- Fila 20: Roster manual (20-20)
- Fila 24: Libros de asistencia se llenan “Día 20”

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)