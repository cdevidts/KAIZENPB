# Fila 15 + Fila 22 + Fila 23 - Información laboral y vigencias dispersas entre RRHH y Operaciones

## Ficha Ejecutiva
- Filas combinadas: 15, 22, 23
- Áreas involucradas: Operaciones, Recursos Humanos
- Importancia promedio: 3.33/5
- IBO combinado estimado: 67/100
- KAIZEN dominante: Movimiento

## Descripción Combinada Propuesta
La operación no cuenta con acceso oportuno y consolidado a vigencias críticas (anexos, exámenes, estado documental), lo que incrementa dependencia de RRHH y respuestas reactivas.

## Subproblemas Comunes
- Falta de un silo con la información para acceder sin preguntar a RRHH
- Alertas solo para el último documentado (Profundizar de ser elegido)
- JP preguntan a RRHH

## Cuello De Botella Transversal
- El flujo cruza más de un área con responsabilidades no estandarizadas, datos no interoperables y control tardío. Por eso aparecen síntomas distintos para el mismo problema estructural.

## Impacto Operacional Combinado
- Multiplica retrabajo entre áreas, aumenta tiempos de ciclo y reduce capacidad de anticipar desvíos de costo/plazo/calidad.
- Incrementa el riesgo de decisiones reactivas (urgencia) en lugar de gestión preventiva.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: consulta operativa y control preventivo de vigencias laborales/médicas.
- Stack tentativo: **Power Apps + Dataverse/SharePoint + Power Automate** con permisos RBAC.
- Automatización: vista única por trabajador/proyecto, alertas de vencimientos y escalamientos automáticos.
- Licenciamiento foco: acceso controlado multiárea con seguridad corporativa y trazabilidad.
- Enfoque de despliegue recomendado: piloto cross-área por Wave de 90 días, con baseline y decisión Go/No-Go al cierre.

## Semáforo De Gravedad
- Color asignado: **Amarillo Medio-Alto (#FBC02D)**
- Base de asignación: promedio de importancia de filas combinadas **3.33/5**.
- Lectura ejecutiva: Impacto relevante en un área o flujo clave, con efectos controlables.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Naranja Implementación Media (#EF6C00)**
- Ventana tentativa: **9-12 semanas**
- Lectura ejecutiva: Integra múltiples componentes M365/Dynamics + UAT formal.

## Recomendación De Formulación Única
- Definir un owner transversal del proceso (no por silo), una estructura de datos común y un único punto de verdad para seguimiento operativo-financiero.

## Trazabilidad
- Fila 15: Acceso a información de trabajadores disperso
- Fila 22: Alertas por vencimiento de anexos
- Fila 23: No visibilidad de datos de la mutual (ACHS) para los JP (ej: exámenes vigentes)

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)