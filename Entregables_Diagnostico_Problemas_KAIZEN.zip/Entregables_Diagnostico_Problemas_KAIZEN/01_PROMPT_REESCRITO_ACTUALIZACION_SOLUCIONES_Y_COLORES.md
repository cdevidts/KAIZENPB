# Prompt Reescrito (Optimizado para objetivo ejecutivo-técnico)

Actúa como consultor principal de transformación digital para PROTAB, en modo **pre-implementación ejecutiva**.

## Objetivo
Actualizar **todos los archivos de problemas** existentes para agregar:
1. **Solución tentativa detallada con ofimática Microsoft** (precisa, no extensa).
2. **Semáforo de gravedad por color** (basado en score ya existente).
3. **Semáforo de tiempo de implementación tentativa por color** (quick wins vs implementaciones largas).
4. Un archivo independiente de **glosa del mapa de colores** para ambas categorías.

## Fuentes obligatorias
- `Transformación IA/Transformación IA/Research y Estudio/State of AI RAW.docx`
- `Transformación IA/Transformación IA/Research y Estudio/TextBook AI in Protab.pdf`
- Diagnósticos ya generados en `Entregables_Diagnostico_Problemas_KAIZEN`
- Conocimiento técnico propio sobre ecosistema Microsoft (M365, Copilot, Power Platform, Dynamics, Project, Power BI, Purview, RBAC, DLP).

## Criterios de actualización por archivo
Para **cada archivo de problema** (individual y merged):
- Agregar una sección: **“Solución Tentativa Microsoft (Pre-Estudio Técnico)”**.
- Explicar con precisión:
  - En qué paso exacto del flujo operacional se inserta la solución.
  - Qué producto/automatización/licencia Microsoft se usaría.
  - Qué resultado operativo inmediato habilita.
- Mantener foco pre-diagnóstico: suficiente para que un CEO técnico entienda rápidamente el sentido y viabilidad, sin sobredimensionar detalle de implementación.

Luego agregar dos secciones de color:
1. **Semáforo de Gravedad**: derivado del score ya existente.
2. **Semáforo de Tiempo de Implementación Tentativa**: color según esfuerzo/plazo estimado.

## Entregable adicional obligatorio
Crear `Glosa_Mapa_Colores.md` con:
- Escala de color para gravedad (score→color).
- Escala de color para tiempo de implementación (quick win→estructural).
- Significado ejecutivo de cada color.

## Reglas de calidad
- Mantener consistencia terminológica entre archivos.
- No eliminar contenido diagnóstico previo; solo enriquecer.
- Mantener trazabilidad y lenguaje profesional.
- Propuestas Microsoft deben ser realistas para entorno PROTAB (M365-first, gobierno ligero, seguridad corporativa).
