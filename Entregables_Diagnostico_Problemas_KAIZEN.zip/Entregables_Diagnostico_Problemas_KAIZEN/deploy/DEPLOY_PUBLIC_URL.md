# Deploy Profesional del Sitio Kaizen (URL pública)

Este proyecto ya quedó preparado para publicar `kaizen_web` como sitio estático.

## 1) Preparar artefacto de deploy

Desde `Transformación IA/Entregables_Diagnostico_Problemas_KAIZEN`:

```bash
npm run deploy:prepare
```

Eso genera `public_site/` con el sitio listo para producción.

## 2) Opción A (Recomendada): GitHub Pages con deploy automático

Requisitos:
- Repositorio en GitHub con rama `main`
- GitHub Pages habilitado en el repo (Source: GitHub Actions)
- Recomendado: que el repo tenga como raíz esta carpeta `Entregables_Diagnostico_Problemas_KAIZEN`

Pasos:
1. Subir esta carpeta al repo.
2. Confirmar que existe `.github/workflows/deploy-gh-pages.yml`.
3. Hacer push a `main`.
4. Ver la URL pública en `Actions` > workflow > `deploy`.

## 3) Opción B: Netlify

Ya incluye `netlify.toml`.

Pasos:
1. Importar repositorio en Netlify.
2. Base directory: `Transformación IA/Entregables_Diagnostico_Problemas_KAIZEN`
3. Build command: `npm run deploy:prepare`
4. Publish directory: `public_site`
5. Deploy.

## 4) Opción C: Vercel

Ya incluye `vercel.json`.

Pasos:
1. Importar repositorio en Vercel.
2. Root directory: `Transformación IA/Entregables_Diagnostico_Problemas_KAIZEN`
3. Vercel detectará build/output automáticamente.
4. Deploy.

## Dominio personalizado (opcional)

- GitHub Pages: Settings > Pages > Custom domain.
- Netlify/Vercel: Domain settings.

## Nota

No se publica automáticamente desde esta sesión porque requiere tus credenciales del proveedor (GitHub/Netlify/Vercel). La configuración ya está lista para que el despliegue sea inmediato.
