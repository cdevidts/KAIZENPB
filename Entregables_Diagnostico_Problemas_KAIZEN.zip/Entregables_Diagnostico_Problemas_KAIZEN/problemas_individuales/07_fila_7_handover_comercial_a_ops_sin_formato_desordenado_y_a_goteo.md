# Fila 7 - Handover Comercial a OPS sin formato (desordenado y a goteo)

## Ficha Ejecutiva
- Área origen: **Comercial**
- Importancia operacional: **4/5 (Alto)**
- Indicador de beneficio por resolver (IBO): **80/100**
- Clasificación KAIZEN principal: **Transporte/Traspasos**
- Clasificación KAIZEN secundaria: **Defectos + Espera**

## Descripción Del Problema
Handover Comercial a OPS sin formato (desordenado y a goteo)

## Proceso Operacional Afectado
Handover de proyecto ganado desde Comercial a Operaciones

## Dónde Se Arma El Cuello De Botella
No hay formato estándar de traspaso (estructura de carpeta/checklist/SLA de revisión).

## Subproblemas Detectados
- OPS rehace Gantts y recopila manualmente

## Impacto En La Operación
- Áreas/roles afectados: Comercial, Operaciones, Jefes de Proyecto
- KPI/impacto relevante: Re-trabajo de planificación; detección tardía de vacíos de alcance; retrasos de arranque.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- 4.1 Traspaso de información a Operaciones no estandarizado (sin estructura de carpeta / checklist)
  - ""Cuando nosotros le pasamos un pensemos de que nos fuimos acá al cierre y después del cierre nosotros ya pensemos de que fue nos ganamos el proyecto... después pasa el proceso final, entre comillas, en donde nosotros le entregamos la información a operaciones que no está estan..."
  - ""No sé la estructura de carpeta para pasarte la información va a ser A, B, C, D, contacto, número de teléfono, E el cliente, esto le gusta, esto no le gusta. Eso no tiene estructura. Cuando pasamos la información es muy desordenada, muy desordenada y a goteo." (Andrés Alberto ..."
- 4.2 Detección tardía de problemas post-traspaso (se levantan semanas después)
  - ""A mí me molesta mucho que un mes después me levanten la mano, oye Andrés, esta weá estaba mala un mes después, Sí, cómo te moráis un mes." (Andrés Alberto Soto Jaña)"
  - ""Tenéis 5 días para revisar, pero revísalo y alégame porque la weá en esos cinco días encontraste deficiencia y levantéis la mano y lo mejoramos... Pero de repente pasa de que pasa un mes después y recién están viendo el proyecto y se dieron cuenta de que hay una weá que va a ..."

## Relación Con Problemas Similares (Merge)
- `M02`: Fila 7 + Fila 17 - Handover Comercial-Operaciones sin estándar de alcance
- Propuesta de descripción combinada: este problema debe tratarse de forma transversal con las filas relacionadas para evitar soluciones aisladas que trasladen el cuello de botella a otra área.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: en el handover post-adjudicación, antes del kick-off operativo.
- Stack tentativo: **SharePoint + Teams + Power Automate** para paquete de traspaso estandarizado (checklist, carpeta, responsables).
- Automatización: creación automática de estructura documental, lista de pendientes y control de ventana de revisión (SLA 5 días).
- Licenciamiento foco: M365-first, trazabilidad de traspaso y evidencia de aceptación por Operaciones.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Naranja Alto (#F57C00)**
- Base de asignación: score actual **4/5** del documento.
- Lectura ejecutiva: Impacto alto multiárea o en un proceso crítico de negocio.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Amarillo Implementación Corta (#F9A825)**
- Ventana tentativa: **5-8 semanas**
- Lectura ejecutiva: Requiere estandarización de proceso y automatizaciones moderadas.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)