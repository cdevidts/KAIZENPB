# Fila 2 - 1. Project (planificado: Gantt, asignaciones, horas, línea base) vs. Dynamics (carga HH, aprobación HH por JP, HH como registro contable, dato real ocurrido) vs. BI (horas consumidas por proyecto y por período, después de que ocurrieron) → No hay enlace entre la data (Planificado vs. real, trazabilidad, silo de información, sin integración automática)

## Ficha Ejecutiva
- Área origen: **Ingeniería**
- Importancia operacional: **5/5 (Crítico)**
- Indicador de beneficio por resolver (IBO): **100/100**
- Clasificación KAIZEN principal: **Sobreprocesamiento**
- Clasificación KAIZEN secundaria: **Espera + Mura (variabilidad)**

## Descripción Del Problema
1. Project (planificado: Gantt, asignaciones, horas, línea base) vs. Dynamics (carga HH, aprobación HH por JP, HH como registro contable, dato real ocurrido) vs. BI (horas consumidas por proyecto y por período, después de que ocurrieron) → No hay enlace entre la data (Planificado vs. real, trazabilidad, silo de información, sin integración automática)

## Proceso Operacional Afectado
Planificación y control integrado de proyectos (Project-Dynamics-BI)

## Dónde Se Arma El Cuello De Botella
La reconciliación planificado vs real se arma manualmente en Excel porque Project, Dynamics y BI no comparten estructura común.

## Subproblemas Detectados
- Uso excesivo de Excel manual para hacer la comparativa y juntar la data (Data en constante cambio → limita eficiencia)
- Dynamics orientado a uso y carga de datos, no a visualización ni análisis.
- Ingeniería visualiza desvíos después de que sucedieron y no tiene claro cómo Operaciones lleva el cronograma hasta reportes. (Cada JP a su pinta, sin información cruzada en vivo con otras áreas por project local)
- Shadow IT. Licencias Project individuales e imposibilidad de entrelazar planillas.
- Antes había PMO (Project Management Office) que absorbía carga de recopilar y reportar. Hoy se cubre con trabajo manual extra.

## Impacto En La Operación
- Áreas/roles afectados: Ingeniería, Operaciones, Jefes de Proyecto, Gerencia de Proyectos/Finanzas
- KPI/impacto relevante: Desvío HH y costo detectado tarde; 4-6 h/semana de reporte manual por JP (referencia canónica); riesgo directo sobre márgenes 15-25%.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- 1.1 Incompatibilidad estructural entre Project y Dynamics
  - "Ese match entre la proyección versus lo que está ocurriendo, que es lo que te está mostrando este reporte a través del Dynamics, es lo que a las finales, en su momento hablábamos de que pudieran hacer match y que pudiera verse en forma automatizada. (Manuel Troncoso Salas)"
  - "Los formatos tanto del Project como del Dynamics no son equivalentes, entonces ni siquiera a nivel de aplicativo o de base de datos por decirlo de alguna forma, no son compatibles. Entonces hay que meter un traductor entre medio para que haga esa traducción desde un mundo al o..."
- 1.2 Proceso manual de reconciliación en Excel
  - "Lo único que hice fue todo manual. Agarré los datos en Dynamics en formato manual, los volqué en una... base de datos... Y por otro lado esto es lo que era lo planificado. (Manuel Troncoso Salas)"
  - "Está hecho a mano... Los descargué. Me parece que esto los descargué directo del BI. (Manuel Troncoso Salas)"
- 1.3 Falta de visibilidad en tiempo real
  - "El Dynamics solamente es para ver post, es cuando ellos... meten su hora en el Dynamics. (Manuel Troncoso Salas)"
  - "Hoy en día nosotros estamos jugando el Dynamics para lo que es lo que pasó después de ejecutar. Lo que nos falta es tratar de llevar la proyección de lo que va a suceder a un modelo. (Manuel Troncoso Salas)"

## Relación Con Problemas Similares (Merge)
- `M01`: Fila 2 + Fila 10 + Fila 13 + Fila 16 - Planificación no integrada, Shadow IT y vacío PMO
- Propuesta de descripción combinada: este problema debe tratarse de forma transversal con las filas relacionadas para evitar soluciones aisladas que trasladen el cuello de botella a otra área.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: justo después de la aprobación de HH en Dynamics y antes del reporte semanal/mensual de control.
- Stack tentativo: **Project Plan 3 (línea base y ruta crítica) + Dynamics 365 F&O + Power BI** con modelo de datos común.
- Automatización: **Power Automate** para sincronizar hitos/tareas/HH y generar dataset de “Planificado vs Real” en un repositorio único.
- Licenciamiento foco: Project Plan 3 para JPs/planificador, Power BI Pro para líderes y opcional M365 Copilot para análisis narrativo de desvíos.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Rojo Crítico (#D32F2F)**
- Base de asignación: score actual **5/5** del documento.
- Lectura ejecutiva: Impacto transversal sobre operación completa, margen y caja.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Rojo Implementación Extendida (#C62828)**
- Ventana tentativa: **13-20 semanas**
- Lectura ejecutiva: Cambio estructural multiárea con integración profunda y gestión del cambio.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)