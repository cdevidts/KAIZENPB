# Fila 3 - Errores y sobrecostos BOM

## Ficha Ejecutiva
- Área origen: **Ingeniería**
- Importancia operacional: **4/5 (Alto)**
- Indicador de beneficio por resolver (IBO): **80/100**
- Clasificación KAIZEN principal: **Defectos**
- Clasificación KAIZEN secundaria: **Inventario + Espera**

## Descripción Del Problema
Errores y sobrecostos BOM

## Proceso Operacional Afectado
Diseño BOM y traspaso a abastecimiento/compras

## Dónde Se Arma El Cuello De Botella
Códigos duplicados y diferencia entre BOM crítico/detalle fuerzan correcciones y compras redundantes.

## Subproblemas Detectados
- Múltiples entradas/códigos para un mismo ítem (Difieren en descripción, unidad de medida, etc.)
- Revisar stock se entorpece (Distinto stock para dos códigos del mismo ítem)
- No hay proceso formal (o herramienta) de revisión / chequeo cruzado de BOMs

## Impacto En La Operación
- Áreas/roles afectados: Ingeniería, Operaciones, Compras, Bodega, Finanzas
- KPI/impacto relevante: Sobrecosto por compra duplicada; quiebres de stock por codificación; atraso de compras críticas.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- 2.1 Errores en códigos de ítems del BOM
  - "Muchas veces que hay algún tipo de dispositivo que tiene más de un código, entonces es el problema que se nos genera... Ten otro acá en una y media pulgada y códigos distintos... Entonces ¿qué es lo que sucede? A veces cuando emiten los chiquillos los códigos del BOM, meten un..."
  - "Eso no implica que se nos aumenta el inventario con el sobrecosto respectivo por ejemplo uno de los problemas que se genera cuando en los BOMs se ponen los códigos que no compran. (Manuel Troncoso Salas)"
- 2.2 Desfase entre BOM crítico y BOM de detalle
  - "Nosotros definimos dos tipos de BOM: el BOM crítico que llamamos y el BOM de detalle. Entonces muchas veces cuando el proyecto se empieza a trazar, ¿qué es lo que sucede? Nosotros necesitamos construir, sentarse ciertas piezas o ciertos... tablero o gabinete... Pero ¿qué pasa?..."
  - "Como estamos apurados no llegamos a tiempo. Entonces por eso que lo que se hace muchas veces es tirar un boom de detalles previo donde tú por ejemplo, no sé, te compras las tuberías, te compras el tablero y lo que es más fino... se deja para el final. (Manuel Troncoso Salas)"
- 2.3 Tensión entre urgencia y precisión
  - "Si la ingeniería fuera probada y se le diera el tiempo para que el desarrollo del boom fuera lo más exacto posible, significaría que nosotros después de recién aprobar la ingeniería generamos los boom de detalle. ¿Pero eso qué pasa? Que para poder comprar después esos material..."

## Relación Con Problemas Similares (Merge)
- `M03`: Fila 3 + Fila 12 - BOM con errores y compras manuales línea a línea
- Propuesta de descripción combinada: este problema debe tratarse de forma transversal con las filas relacionadas para evitar soluciones aisladas que trasladen el cuello de botella a otra área.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: antes de liberar BOM a compras, en el punto de validación técnica.
- Stack tentativo: **Power Apps + Dataverse + SharePoint** para catálogo maestro de ítems y equivalencias de códigos.
- Automatización: flujo de validación dual Ingeniería/Operaciones con reglas de duplicados y alertas de inconsistencias.
- Licenciamiento foco: Power Apps/Automate (premium si hay conectores Dynamics) y gobierno de datos de maestros.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Naranja Alto (#F57C00)**
- Base de asignación: score actual **4/5** del documento.
- Lectura ejecutiva: Impacto alto multiárea o en un proceso crítico de negocio.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Naranja Implementación Media (#EF6C00)**
- Ventana tentativa: **9-12 semanas**
- Lectura ejecutiva: Integra múltiples componentes M365/Dynamics + UAT formal.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)