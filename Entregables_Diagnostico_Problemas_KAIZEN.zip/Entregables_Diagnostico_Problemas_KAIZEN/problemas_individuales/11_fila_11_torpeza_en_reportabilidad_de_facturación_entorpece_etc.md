# Fila 11 - Torpeza en reportabilidad de facturación entorpece ETC

## Ficha Ejecutiva
- Área origen: **Operaciones**
- Importancia operacional: **4/5 (Alto)**
- Indicador de beneficio por resolver (IBO): **80/100**
- Clasificación KAIZEN principal: **Movimiento**
- Clasificación KAIZEN secundaria: **Espera + Sobreprocesamiento**

## Descripción Del Problema
Torpeza en reportabilidad de facturación entorpece ETC

## Proceso Operacional Afectado
ETC y proyección de gastos/facturación en operación

## Dónde Se Arma El Cuello De Botella
La información para proyectar costos está dispersa en carpetas y documentos, sin repositorio único confiable.

## Subproblemas Detectados
- JP deben buscar información en distintas fuentes
- Retrasos en proyección de gastos

## Impacto En La Operación
- Áreas/roles afectados: Operaciones, Finanzas, Jefes de Proyecto
- KPI/impacto relevante: Retrasos en forecast de gasto; pérdida de tiempo de búsqueda; menor calidad del cierre ETC.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- 3.1 JP deben buscar en distintas fuentes
  - ""Para buscar información, lo que hacemos es abrir estas carpetas y meternos a leer y leer; lo que sería ideal es que estuviera en un único lugar." (Rodrigo A. Parra Macaya)"
  - ""Al final tengo que revisar el contrato, revisar la carpeta, revisar los costos… y es pérdida de tiempo." (Rodrigo A. Parra Macaya)"
- 3.2 Retrasos en proyección de gastos
  - ""Paráfrasis: se generan retrasos en la proyección de gastos porque la información llega tarde y se reconstruye desde varias fuentes." (Rodrigo A. Parra Macaya)"

## Relación Con Problemas Similares (Merge)
- `M07`: Fila 6 + Fila 11 - Gobernanza débil de HH/costos desde preventa hasta ETC
- Propuesta de descripción combinada: este problema debe tratarse de forma transversal con las filas relacionadas para evitar soluciones aisladas que trasladen el cuello de botella a otra área.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: armado de ETC y forecast mensual de costos/facturación.
- Stack tentativo: **SharePoint/Dataverse + Power BI + Copilot Chat** para consulta consolidada de contrato/costos/documentos.
- Automatización: indexación de documentos críticos y dataset único para variaciones de gasto y avance.
- Licenciamiento foco: repositorio gobernado + tablero de ETC para evitar reconstrucción manual desde carpetas dispersas.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Naranja Alto (#F57C00)**
- Base de asignación: score actual **4/5** del documento.
- Lectura ejecutiva: Impacto alto multiárea o en un proceso crítico de negocio.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Naranja Implementación Media (#EF6C00)**
- Ventana tentativa: **9-12 semanas**
- Lectura ejecutiva: Integra múltiples componentes M365/Dynamics + UAT formal.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)