# Fila 9 - Reportabilidad manual intensiva

## Ficha Ejecutiva
- Área origen: **Operaciones**
- Importancia operacional: **5/5 (Crítico)**
- Indicador de beneficio por resolver (IBO): **100/100**
- Clasificación KAIZEN principal: **Sobreprocesamiento**
- Clasificación KAIZEN secundaria: **Defectos + Muri (sobrecarga)**

## Descripción Del Problema
Reportabilidad manual intensiva

## Proceso Operacional Afectado
Reportabilidad operativa diaria, semanal y mensual al cliente

## Dónde Se Arma El Cuello De Botella
Entradas de terreno no estandarizadas obligan edición manual, cruce con Gantt y consolidación artesanal.

## Subproblemas Detectados
- Cruzar info sucedida con línea base, Curva S; consolidar reportes diarios a semanal y mensual
- Falta de herramientas para recopilar la info completa de los reportes (ej: explicaciones de desvíos en un correo)
- Falta de un formato estándar para reportes

## Impacto En La Operación
- Áreas/roles afectados: Operaciones, Supervisores de terreno, Jefes de Proyecto, Cliente
- KPI/impacto relevante: 3-6 h/semana por proyecto para consolidar reportes (referencia canónica); mayor tiempo no facturable.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- 1.1 Falta de herramientas para recopilar la info completa de los reportes (ej: explicaciones de desvíos en un correo)
  - ""Para reportar al cliente yo dependo de la información que nazca desde terreno; mi supervisor en terreno me tiene que entregar una información clara para yo poder reportar." (Hugo Ricardo Jibaja Salas)"
  - ""A mí el viejo de terreno me entrega un reporte que primero viene con mala redacción, con faltas de ortografía y hay cosas que no completan o que se omiten. Entonces ese podría ser el input... sin tener que nosotros quizás revisarlo al detalle" (Felipe Ignacio Bravo Pérez, Reu..."
- 1.2 Falta de un formato estándar para reportes
  - ""Hay que mandar el reporte semanal. Y hay distintos formatos, distintos tipos de escritura, y ahí ya nos trancamos." (Hugo Ricardo Jibaja Salas)"
  - ""Si las explicaciones no vienen en el reporte, te las mandan por un correo y ahí uno tiene que ir juntando la información." (Hugo Ricardo Jibaja Salas)"

## Relación Con Problemas Similares (Merge)
- `M06`: Fila 9 + Fila 14 + Fila 18 - Reportabilidad operativa manual y desvíos tardíos
- Propuesta de descripción combinada: este problema debe tratarse de forma transversal con las filas relacionadas para evitar soluciones aisladas que trasladen el cuello de botella a otra área.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: captura del reporte diario en terreno y consolidación semanal para cliente.
- Stack tentativo: **Power Apps (captura estructurada) + SharePoint + Power Automate + Copilot en Word**.
- Automatización: consolidación automática diario→semanal, adjuntos de fotos/evidencias y resumen narrativo preformateado.
- Licenciamiento foco: Power Platform con trazabilidad documental y reducción de HH senior no facturables.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Rojo Crítico (#D32F2F)**
- Base de asignación: score actual **5/5** del documento.
- Lectura ejecutiva: Impacto transversal sobre operación completa, margen y caja.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Naranja Implementación Media (#EF6C00)**
- Ventana tentativa: **9-12 semanas**
- Lectura ejecutiva: Integra múltiples componentes M365/Dynamics + UAT formal.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)