# Fila 24 - Libros de asistencia se llenan “Día 20”

## Ficha Ejecutiva
- Área origen: **Recursos Humanos**
- Importancia operacional: **4/5 (Alto)**
- Indicador de beneficio por resolver (IBO): **80/100**
- Clasificación KAIZEN principal: **Defectos**
- Clasificación KAIZEN secundaria: **Sobreprocesamiento + Espera**

## Descripción Del Problema
Libros de asistencia se llenan “Día 20”

## Proceso Operacional Afectado
Registro diario de asistencia en libro

## Dónde Se Arma El Cuello De Botella
El registro se completa de forma tardía (“día 20”) y no refleja disciplina diaria real.

## Subproblemas Detectados
- No se llenan día a día ordenadamente. Los llenan el día 20 a la rápida.

## Impacto En La Operación
- Áreas/roles afectados: RRHH, Supervisión terreno, Jefes de Proyecto
- KPI/impacto relevante: Menor confiabilidad de respaldo de asistencia; más correcciones al cierre 20-20.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- RRHH 5 Libros de asistencia se llenan “día 20” y no día a día ordenadamente
  - ""El libro parece que lo llenan el 20… no lo hacen día a día." (Mayra Concha Ramos)"
  - ""Se entiende, porque estar en terreno es otra cosa… es imposible firmar el día del libro." (Mayra Concha Ramos)"

## Relación Con Problemas Similares (Merge)
- `M05`: Fila 20 + Fila 24 - Control de asistencia 20-20 con registros tardíos
- Propuesta de descripción combinada: este problema debe tratarse de forma transversal con las filas relacionadas para evitar soluciones aisladas que trasladen el cuello de botella a otra área.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: registro diario de asistencia en terreno, no sólo al corte.
- Stack tentativo: **Power Apps móvil (con modo offline) + SharePoint/Dataverse + Power BI RRHH**.
- Automatización: captura diaria, sincronización al recuperar conectividad y bloqueo de edición tardía con auditoría.
- Licenciamiento foco: mayor calidad del dato fuente para cierre 20-20 y menos corrección manual.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Naranja Alto (#F57C00)**
- Base de asignación: score actual **4/5** del documento.
- Lectura ejecutiva: Impacto alto multiárea o en un proceso crítico de negocio.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Amarillo Implementación Corta (#F9A825)**
- Ventana tentativa: **5-8 semanas**
- Lectura ejecutiva: Requiere estandarización de proceso y automatizaciones moderadas.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)