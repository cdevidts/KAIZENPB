# Fila 6 - Inexistencia protocolo formal validación HH con Ingeniería

## Ficha Ejecutiva
- Área origen: **Comercial**
- Importancia operacional: **4/5 (Alto)**
- Indicador de beneficio por resolver (IBO): **80/100**
- Clasificación KAIZEN principal: **Defectos**
- Clasificación KAIZEN secundaria: **Sobreprocesamiento + Espera**

## Descripción Del Problema
Inexistencia protocolo formal validación HH con Ingeniería

## Proceso Operacional Afectado
Estimación de HH de preventa y validación técnica con Ingeniería

## Dónde Se Arma El Cuello De Botella
No existe regla obligatoria de cuándo y cómo validar HH con Ingeniería, por lo que la corrección ocurre tarde.

## Subproblemas Detectados
- Coordinación informal
- Ingeniería y OPS corrigen en operación (cambios circunstanciales)
- Sugiere sistematización con prueba y error

## Impacto En La Operación
- Áreas/roles afectados: Comercial, Ingeniería, Operaciones, Control de Proyecto
- KPI/impacto relevante: Brecha HH vendidas vs HH consumidas; desviación de margen por estimación no validada en origen.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- 3.1 Validación se hace 'intrínseca' pero no obligatoria ni estandarizada (umbral, reglas)
  - ""Algo que yo este año voy a tratar desde que se. Si bien es cierto, es un proceso como que está ya intrínseco en prota, Cristóbal, no hay nada que está escrita así como obligatoria o no sé, estandarizada." (Andrés Alberto Soto Jaña)"
  - ""Por decirte, ¿Sabes que? Cuando el proyecto pase los 150 mil dólares, sí o sí ingeniería me tenís que hacer el estudio. No tanto como conversarlo, sino que tú entrégame la hora. Eso es algo que yo tengo que. Tengo que mejorar." (Andrés Alberto Soto Jaña)"
- 3.2 Discrepancias relevantes entre estimación comercial/preventa y revisión de ingeniería
  - ""Después igual tiene que ser revisado con ingeniería, ¿Cachai? Porque finalmente yo te puedo decir 150 horas por ingeniería. Puede decirme. No, son 400 y pasa. Y pasa, Cristóbal." (Andrés Alberto Soto Jaña)"
  - ""De hecho nosotros tenemos a nivel de prota tiene una deficiencia con respecto a eso, en el sentido de cuánta hora se verificaron y cuánta hora después se consumieron." (Andrés Alberto Soto Jaña)"

## Relación Con Problemas Similares (Merge)
- `M07`: Fila 6 + Fila 11 - Gobernanza débil de HH/costos desde preventa hasta ETC
- Propuesta de descripción combinada: este problema debe tratarse de forma transversal con las filas relacionadas para evitar soluciones aisladas que trasladen el cuello de botella a otra área.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: gate previo al envío de propuesta cuando monto/criticidad supera umbral definido.
- Stack tentativo: **Teams Approvals + Power Automate + Planner** para circuito formal de validación HH con Ingeniería.
- Automatización: creación automática de tarea de revisión, SLA de respuesta y registro de aprobación/rechazo con trazabilidad.
- Licenciamiento foco: M365 estándar + flujos de aprobación, sin dependencia inicial de desarrollo custom.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Naranja Alto (#F57C00)**
- Base de asignación: score actual **4/5** del documento.
- Lectura ejecutiva: Impacto alto multiárea o en un proceso crítico de negocio.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Amarillo Implementación Corta (#F9A825)**
- Ventana tentativa: **5-8 semanas**
- Lectura ejecutiva: Requiere estandarización de proceso y automatizaciones moderadas.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)