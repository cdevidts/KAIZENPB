# Fila 14 - Reportes diarios de terreno de mala calidad

## Ficha Ejecutiva
- Área origen: **Operaciones**
- Importancia operacional: **4/5 (Alto)**
- Indicador de beneficio por resolver (IBO): **80/100**
- Clasificación KAIZEN principal: **Defectos**
- Clasificación KAIZEN secundaria: **Sobreprocesamiento**

## Descripción Del Problema
Reportes diarios de terreno de mala calidad

## Proceso Operacional Afectado
Calidad de reportes diarios provenientes de terreno

## Dónde Se Arma El Cuello De Botella
Reportes llegan con redacción/estructura insuficiente y deben corregirse antes de uso contractual.

## Subproblemas Detectados
- Deben revisar y corregir faltas antes de entregar a cliente

## Impacto En La Operación
- Áreas/roles afectados: Supervisores, Operaciones, Jefes de Proyecto, Cliente
- KPI/impacto relevante: Horas de corrección y unión de reportes diarios a semanales; riesgo de evidencia incompleta.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- 6.0 Reportes diarios de terreno de mala calidad; deben revisar y corregir faltas antes de entregar a cliente
  - ""Se gastan horas… en corregir los reportes diarios, unirlos en reportes semanales." (Hugo Ricardo Jibaja Salas)"
  - ""Mi supervisor en terreno me tiene que entregar una información clara para yo poder reportar." (Hugo Ricardo Jibaja Salas)"

## Relación Con Problemas Similares (Merge)
- `M06`: Fila 9 + Fila 14 + Fila 18 - Reportabilidad operativa manual y desvíos tardíos
- Propuesta de descripción combinada: este problema debe tratarse de forma transversal con las filas relacionadas para evitar soluciones aisladas que trasladen el cuello de botella a otra área.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: emisión del reporte diario por supervisor en terreno.
- Stack tentativo: **Power Apps/Forms + Copilot en Word/Teams** para redacción asistida y formato estandarizado.
- Automatización: validación de campos obligatorios antes de envío y corrección de estilo previa a reporte cliente.
- Licenciamiento foco: quick win de calidad de entrada para reducir corrección posterior de JPs.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Naranja Alto (#F57C00)**
- Base de asignación: score actual **4/5** del documento.
- Lectura ejecutiva: Impacto alto multiárea o en un proceso crítico de negocio.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Verde Quick Win (#2E7D32)**
- Ventana tentativa: **1-4 semanas**
- Lectura ejecutiva: Configurable con cambios acotados y mínima integración.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)