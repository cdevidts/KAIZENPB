# Fila 15 - Acceso a información de trabajadores disperso

## Ficha Ejecutiva
- Área origen: **Operaciones**
- Importancia operacional: **3/5 (Medio-Alto)**
- Indicador de beneficio por resolver (IBO): **60/100**
- Clasificación KAIZEN principal: **Movimiento**
- Clasificación KAIZEN secundaria: **Espera**

## Descripción Del Problema
Acceso a información de trabajadores disperso

## Proceso Operacional Afectado
Acceso operativo a datos laborales/documentales del personal

## Dónde Se Arma El Cuello De Botella
La información está repartida entre RRHH y responsables específicos, sin “silo” consultable por operación.

## Subproblemas Detectados
- Falta de un silo con la información para acceder sin preguntar a RRHH

## Impacto En La Operación
- Áreas/roles afectados: Operaciones, RRHH, Jefes de Proyecto
- KPI/impacto relevante: Tiempo de espera por datos; decisiones operativas retrasadas por dependencia de terceros.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- 7.0 Acceso a información de trabajadores disperso; falta de un "silo" para acceder sin preguntar a RRHH
  - ""Recursos Humanos tiene sus carpetas aparte… eso deberíamos tenerlo unificado en algún sistema." (Rodrigo A. Parra Macaya)"
  - ""El objetivo es centralizar la información… no es necesario que estemos para tener un archivo que sacarlo de nuestro computador." (Rodrigo A. Parra Macaya)"

## Relación Con Problemas Similares (Merge)
- `M04`: Fila 15 + Fila 22 + Fila 23 - Información laboral y vigencias dispersas entre RRHH y Operaciones
- Propuesta de descripción combinada: este problema debe tratarse de forma transversal con las filas relacionadas para evitar soluciones aisladas que trasladen el cuello de botella a otra área.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: consulta operativa de estado documental/laboral de personal por proyecto.
- Stack tentativo: **Power Apps + Dataverse/SharePoint** como vista única para Operaciones con permisos por rol.
- Automatización: consolidación periódica de fuentes RRHH y búsqueda por trabajador/proyecto/vigencia.
- Licenciamiento foco: acceso controlado (RBAC) y reducción de dependencia de consultas manuales a RRHH.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Amarillo Medio-Alto (#FBC02D)**
- Base de asignación: score actual **3/5** del documento.
- Lectura ejecutiva: Impacto relevante en un área o flujo clave, con efectos controlables.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Naranja Implementación Media (#EF6C00)**
- Ventana tentativa: **9-12 semanas**
- Lectura ejecutiva: Integra múltiples componentes M365/Dynamics + UAT formal.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)