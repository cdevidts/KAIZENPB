# Fila 12 - Solicitudes de compra muy manuales “uno a uno, línea por línea”

## Ficha Ejecutiva
- Área origen: **Operaciones**
- Importancia operacional: **5/5 (Crítico)**
- Indicador de beneficio por resolver (IBO): **100/100**
- Clasificación KAIZEN principal: **Sobreprocesamiento**
- Clasificación KAIZEN secundaria: **Defectos + Espera**

## Descripción Del Problema
Solicitudes de compra muy manuales “uno a uno, línea por línea”

## Proceso Operacional Afectado
Solicitud de compra técnica en Dynamics y validación BOM

## Dónde Se Arma El Cuello De Botella
Ingreso uno-a-uno por línea y BOM con errores generan doble trabajo y ciclo lento de compras.

## Subproblemas Detectados
- Operaciones se hace cargo de las solicitudes de compra; deben ingresar uno a uno ítem por ítem
- Ingeniería envía BOMs que hay que revisar por errores de códigos de ítems
- BOMs sin “spares”
- Proceso no formalizado con etapa de validación de datos

## Impacto En La Operación
- Áreas/roles afectados: Operaciones, Ingeniería, Compras, Bodega
- KPI/impacto relevante: ~2 horas por solicitud de 50 ítems (fuente canónica/entrevista); riesgo de atraso por errores de códigos.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- 4.1 Operaciones ingresa solicitudes de compra ítem por ítem (línea por línea) en Dynamics
  - ""Para un kit de herramientas son 50 ítems… y hay que ingresarla uno a uno. Imagínate: 50 líneas, son como dos horas de tiempo." (Rodrigo A. Parra Macaya)"
  - ""Tienes que ir comprobando línea a línea… y que todos los códigos estén en el sistema." (Rodrigo A. Parra Macaya)"
- 4.2 Ingeniería envía BOMs con errores de códigos de ítems (hay que revisar/corregir)
  - ""Ingeniería te lo manda con códigos erróneos. Entonces tú tenís que ver la cantidad." (Rodrigo A. Parra Macaya)"
  - ""Lamentablemente Ingeniería no entrega el dato y nosotros tenemos que generar la solicitud de compra." (Rodrigo A. Parra Macaya)"
- 4.3 BOMs sin "stocks" / sin spares (material exacto, sin holgura)
  - ""Ingeniería te calcula el material exacto… y nunca hay un spare; cuando se pierde un conector, cagaste." (Rodrigo A. Parra Macaya)"

## Relación Con Problemas Similares (Merge)
- `M03`: Fila 3 + Fila 12 - BOM con errores y compras manuales línea a línea
- Propuesta de descripción combinada: este problema debe tratarse de forma transversal con las filas relacionadas para evitar soluciones aisladas que trasladen el cuello de botella a otra área.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: desde BOM aprobado hacia solicitud de compra en Dynamics.
- Stack tentativo: **Power Apps (carga masiva) + Power Automate + Dynamics 365 F&O**.
- Automatización: validación previa de líneas/códigos y creación bulk de solicitudes de compra, evitando carga uno-a-uno.
- Licenciamiento foco: conectores Dynamics y reglas de calidad de datos antes de emisión.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Rojo Crítico (#D32F2F)**
- Base de asignación: score actual **5/5** del documento.
- Lectura ejecutiva: Impacto transversal sobre operación completa, margen y caja.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Naranja Implementación Media (#EF6C00)**
- Ventana tentativa: **9-12 semanas**
- Lectura ejecutiva: Integra múltiples componentes M365/Dynamics + UAT formal.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)