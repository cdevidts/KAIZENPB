# Fila 13 - Shadow IT – Licencias Project (licencias auto pagadas)

## Ficha Ejecutiva
- Área origen: **Operaciones**
- Importancia operacional: **4/5 (Alto)**
- Indicador de beneficio por resolver (IBO): **80/100**
- Clasificación KAIZEN principal: **Talento no utilizado**
- Clasificación KAIZEN secundaria: **Defectos + Mura**

## Descripción Del Problema
Shadow IT – Licencias Project (licencias auto pagadas)

## Proceso Operacional Afectado
Gobierno de herramientas de planificación y colaboración

## Dónde Se Arma El Cuello De Botella
Uso de licencias personales/locales (Project, IA externa) fragmenta colaboración y control de seguridad/datos.

## Subproblemas Detectados
- Projects (.mpp) no colaborativos
- Uso de IA tipo Chat Gpt, utilizando info de la empresa, pagada por trabajadores

## Impacto En La Operación
- Áreas/roles afectados: Operaciones, Ingeniería, TI, Gerencia
- KPI/impacto relevante: Versionado no colaborativo (.mpp local); dependencia de gasto personal; riesgo de compliance y continuidad.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- 5.1 Shadow TI: uso de herramientas pagadas por personas (Project) y archivos .mpp no colaborativos
  - ""Lo que yo hice fue comprar mi propia licencia y no sé, o sea, no la rendí, netamente un gasto de uno para tener una mejor visualización y quizá una modificación de la carta, pero no tenemos licencia para Project por si acaso, ni tampoco para Visio" (Rodrigo A. Parra Macaya, R..."
  - ""Está en el SharePoint, pero nosotros lo trabajamos con un Project local que pagamos nosotros, no es una licencia oficial, por decirlo así, que esté en la nube y se te actualice junto con Microsoft 365. Es una licencia perpetua" (Felipe Ignacio Bravo Pérez, Reunión Equipo Hugo..."

## Relación Con Problemas Similares (Merge)
- `M01`: Fila 2 + Fila 10 + Fila 13 + Fila 16 - Planificación no integrada, Shadow IT y vacío PMO
- Propuesta de descripción combinada: este problema debe tratarse de forma transversal con las filas relacionadas para evitar soluciones aisladas que trasladen el cuello de botella a otra área.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: capa de gobierno antes del uso de herramientas de planificación/IA en operación.
- Stack tentativo: **Purview + DLP + catálogo de herramientas aprobadas + centralización de licencias M365/Project**.
- Automatización: workflow de solicitud/aprobación de nuevas herramientas y bloqueo de usos no aprobados con datos sensibles.
- Licenciamiento foco: consolidar Project corporativo y uso de Copilot en entorno gobernado (RBAC y compliance).
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Naranja Alto (#F57C00)**
- Base de asignación: score actual **4/5** del documento.
- Lectura ejecutiva: Impacto alto multiárea o en un proceso crítico de negocio.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Amarillo Implementación Corta (#F9A825)**
- Ventana tentativa: **5-8 semanas**
- Lectura ejecutiva: Requiere estandarización de proceso y automatizaciones moderadas.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)