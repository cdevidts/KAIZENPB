# Fila 22 - Alertas por vencimiento de anexos

## Ficha Ejecutiva
- Área origen: **Recursos Humanos**
- Importancia operacional: **3/5 (Medio-Alto)**
- Indicador de beneficio por resolver (IBO): **60/100**
- Clasificación KAIZEN principal: **Espera**
- Clasificación KAIZEN secundaria: **Defectos**

## Descripción Del Problema
Alertas por vencimiento de anexos

## Proceso Operacional Afectado
Control de vigencia de anexos contractuales

## Dónde Se Arma El Cuello De Botella
Alertas parciales y visión reactiva del vencimiento (foco en último documento).

## Subproblemas Detectados
- Alertas solo para el último documentado (Profundizar de ser elegido)

## Impacto En La Operación
- Áreas/roles afectados: RRHH, Operaciones, Jefes de Proyecto
- KPI/impacto relevante: Riesgo de vencimiento no detectado a tiempo; urgencias administrativas evitables.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- RRHH 3 Alertas por vencimiento de anexos solo para el último documentado
  - ""[Paráfrasis] Hoy no tenemos un control/alerta robusta para el vencimiento de anexos; normalmente la visibilidad queda acotada a lo último que está documentado y termina siendo reactivo." (Mayra Concha Ramos)"

## Relación Con Problemas Similares (Merge)
- `M04`: Fila 15 + Fila 22 + Fila 23 - Información laboral y vigencias dispersas entre RRHH y Operaciones
- Propuesta de descripción combinada: este problema debe tratarse de forma transversal con las filas relacionadas para evitar soluciones aisladas que trasladen el cuello de botella a otra área.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: control continuo de ciclo de vida de anexos contractuales.
- Stack tentativo: **Dataverse/SharePoint + Power Automate** con calendario de alertas 60/30/15 días.
- Automatización: notificación a owner + escalamiento automático a jefatura cuando no hay acción.
- Licenciamiento foco: quick win de control preventivo y menor urgencia administrativa.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Amarillo Medio-Alto (#FBC02D)**
- Base de asignación: score actual **3/5** del documento.
- Lectura ejecutiva: Impacto relevante en un área o flujo clave, con efectos controlables.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Verde Quick Win (#2E7D32)**
- Ventana tentativa: **1-4 semanas**
- Lectura ejecutiva: Configurable con cambios acotados y mínima integración.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)