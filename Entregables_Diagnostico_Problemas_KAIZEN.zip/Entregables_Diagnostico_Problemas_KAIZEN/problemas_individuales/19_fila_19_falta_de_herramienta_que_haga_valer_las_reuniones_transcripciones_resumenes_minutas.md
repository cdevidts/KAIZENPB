# Fila 19 - Falta de herramienta que haga valer las reuniones (Transcripciones, resumenes, minutas)

## Ficha Ejecutiva
- Área origen: **Operaciones**
- Importancia operacional: **3/5 (Medio-Alto)**
- Indicador de beneficio por resolver (IBO): **60/100**
- Clasificación KAIZEN principal: **Sobreprocesamiento**
- Clasificación KAIZEN secundaria: **Defectos**

## Descripción Del Problema
Falta de herramienta que haga valer las reuniones (Transcripciones, resumenes, minutas)

## Proceso Operacional Afectado
Gestión de acuerdos y trazabilidad de reuniones

## Dónde Se Arma El Cuello De Botella
Los acuerdos se capturan manualmente (cuaderno/notas sueltas), con riesgo de pérdida o baja trazabilidad.

## Subproblemas Detectados
- No se declararon subproblemas adicionales en la fila.

## Impacto En La Operación
- Áreas/roles afectados: Operaciones, equipos transversales, liderazgo de proyecto
- KPI/impacto relevante: Retrabajo por tareas olvidadas; coordinación menos confiable entre traspasos.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- 11.0 Falta de herramienta que haga valer las reuniones (transcripciones, resúmenes, minutas)
  - ""Yo tengo aquí un cuadernito a mi lado, aquí lo tengo con un lápiz a la antigua. En las reuniones que yo tengo algo importante que tengo que hacer, cuando me lo piden, yo tomo nota y después lo gestiono" (Hugo Ricardo Jibaja Salas, Reunión 1 Hugo, minuto 00:52:56)"
  - ""De hecho yo ahora voy a grabar la información con la reunión, cuando esté con mi colega, me esté traspasando la info, porque voy a tener que estar atento. Oye, que me dijo este para no estar llamándolo" (Hugo Ricardo Jibaja Salas, Reunión 1 Hugo, minuto 00:55:31)"

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: cierre de cada reunión operativa y de traspaso.
- Stack tentativo: **Teams Premium/Copilot + Planner + SharePoint** para minuta automática y tareas con responsable/fecha.
- Automatización: generación de resumen, acuerdos y backlog de acciones post-reunión sin toma manual en cuaderno.
- Licenciamiento foco: habilitar captura de conocimiento y continuidad operacional.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Amarillo Medio-Alto (#FBC02D)**
- Base de asignación: score actual **3/5** del documento.
- Lectura ejecutiva: Impacto relevante en un área o flujo clave, con efectos controlables.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Verde Quick Win (#2E7D32)**
- Ventana tentativa: **1-4 semanas**
- Lectura ejecutiva: Configurable con cambios acotados y mínima integración.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)