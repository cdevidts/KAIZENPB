# Fila 8 - Ausencia de alertas tempranas sobre oportunidades en pipeline

## Ficha Ejecutiva
- Área origen: **Comercial**
- Importancia operacional: **3/5 (Medio-Alto)**
- Indicador de beneficio por resolver (IBO): **60/100**
- Clasificación KAIZEN principal: **Espera**
- Clasificación KAIZEN secundaria: **Movimiento (revisión manual)**

## Descripción Del Problema
Ausencia de alertas tempranas sobre oportunidades en pipeline

## Proceso Operacional Afectado
Gestión de pipeline comercial y priorización de cuentas

## Dónde Se Arma El Cuello De Botella
El monitoreo de estancamientos se hace manual, sin alertas por etapa o inactividad.

## Subproblemas Detectados
- CAM hacen monitoreo manual

## Impacto En La Operación
- Áreas/roles afectados: Comercial, CAM, Gerencia Comercial
- KPI/impacto relevante: Oportunidades dormidas; caída de actividad por cuenta sin detección temprana; menor predictibilidad del pipeline.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- 5.1 No hay alertas para baja actividad o estancamiento por etapa (requiere revisión manual)
  - ""Aquí a mí me encantaría por ejemplo, oye weón, una alerta tenís muy poco en calificar, ¿Qué te está pasando? Hay clientes que no hay atendido, ¿Cachai? Oye, ¿Qué pasa con estos clientes? ¿Esta cuenta por qué está detenida? No he hecho ninguna durante tanto tiempo, ¿Cachai?" (..."
  - ""Eso yo lo puedo ver obviamente pinchando acá, pinchando ya pasando una planilla, pasar una planilla, oye, de repente no hemos propuesto a un cliente durante un año y el cliente ya no trabaja, entonces no hemos trabajado bien una cuenta." (Andrés Alberto Soto Jaña)"

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: seguimiento diario/semanal del pipeline por etapa en CRM.
- Stack tentativo: **Dynamics 365 Sales + Power Automate + Power BI** para alertas de inactividad y estancamiento.
- Automatización: alertas por no-movimiento por etapa/cuenta y digest ejecutivo para CAM y jefatura.
- Licenciamiento foco: reglas de negocio en CRM y reportabilidad ligera sin reingeniería mayor.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Amarillo Medio-Alto (#FBC02D)**
- Base de asignación: score actual **3/5** del documento.
- Lectura ejecutiva: Impacto relevante en un área o flujo clave, con efectos controlables.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Verde Quick Win (#2E7D32)**
- Ventana tentativa: **1-4 semanas**
- Lectura ejecutiva: Configurable con cambios acotados y mínima integración.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)