# Fila 23 - No visibilidad de datos de la mutual (ACHS) para los JP (ej: exámenes vigentes)

## Ficha Ejecutiva
- Área origen: **Recursos Humanos**
- Importancia operacional: **4/5 (Alto)**
- Indicador de beneficio por resolver (IBO): **80/100**
- Clasificación KAIZEN principal: **Movimiento**
- Clasificación KAIZEN secundaria: **Espera + Defectos**

## Descripción Del Problema
No visibilidad de datos de la mutual (ACHS) para los JP (ej: exámenes vigentes)

## Proceso Operacional Afectado
Disponibilidad de datos de exámenes mutual para operación

## Dónde Se Arma El Cuello De Botella
JP no tiene acceso directo y depende de RRHH/encargados para validar vigencias.

## Subproblemas Detectados
- JP preguntan a RRHH

## Impacto En La Operación
- Áreas/roles afectados: RRHH, Operaciones, Jefes de Proyecto, Prevención
- KPI/impacto relevante: Retraso de decisiones operativas por dependencia informacional; riesgo de asignación sin visibilidad completa.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- RRHH 4 No visibilidad de datos de la mutual (ACH) para los JP (ej.: exámenes vigentes)
  - ""Hay dos procesos que tenemos en común con operaciones… uno es contratos y otro es examen médico." (Mayra Concha Ramos)"
  - ""Como esta es nuestra mutual, este acceso también lo tiene Melissa y también lo tiene Rodrigo Plaza." (Mayra Concha Ramos)"

## Relación Con Problemas Similares (Merge)
- `M04`: Fila 15 + Fila 22 + Fila 23 - Información laboral y vigencias dispersas entre RRHH y Operaciones
- Propuesta de descripción combinada: este problema debe tratarse de forma transversal con las filas relacionadas para evitar soluciones aisladas que trasladen el cuello de botella a otra área.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: validación de vigencias médicas/exámenes antes de asignar personal a operación.
- Stack tentativo: **Power Apps de consulta + repositorio actualizado + RBAC** para acceso operativo controlado.
- Automatización: carga programada de vigencias (API/export) y alertas de próximo vencimiento para JP/RRHH.
- Licenciamiento foco: transparencia de información crítica sin exponer datos fuera de gobernanza.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Naranja Alto (#F57C00)**
- Base de asignación: score actual **4/5** del documento.
- Lectura ejecutiva: Impacto alto multiárea o en un proceso crítico de negocio.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Amarillo Implementación Corta (#F9A825)**
- Ventana tentativa: **5-8 semanas**
- Lectura ejecutiva: Requiere estandarización de proceso y automatizaciones moderadas.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)