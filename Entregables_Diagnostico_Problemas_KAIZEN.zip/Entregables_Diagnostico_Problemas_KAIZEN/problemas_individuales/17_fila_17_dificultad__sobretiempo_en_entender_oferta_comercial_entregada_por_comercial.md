# Fila 17 - Dificultad / sobretiempo en entender oferta comercial entregada por Comercial

## Ficha Ejecutiva
- Área origen: **Operaciones**
- Importancia operacional: **4/5 (Alto)**
- Indicador de beneficio por resolver (IBO): **80/100**
- Clasificación KAIZEN principal: **Transporte/Traspasos**
- Clasificación KAIZEN secundaria: **Defectos + Espera**

## Descripción Del Problema
Dificultad / sobretiempo en entender oferta comercial entregada por Comercial

## Proceso Operacional Afectado
Interpretación de alcance comercial en el arranque operativo

## Dónde Se Arma El Cuello De Botella
Operaciones no recibe un listado claro y accionable de alcances/entregables a cumplir.

## Subproblemas Detectados
- “Que nos reporten un listado con los alcances que tenemos que cumplir”

## Impacto En La Operación
- Áreas/roles afectados: Operaciones, Comercial, Ingeniería
- KPI/impacto relevante: Sobretiempo en entendimiento del alcance; riesgo de ejecución fuera de foco o de omisiones críticas.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- 9.0 Dificultad/sobretiempo en entender oferta comercial entregada por Comercial (alcances)
  - ""Que nos reporten un listado con los alcances que tenemos que cumplir." (Hugo Ricardo Jibaja Salas)"
  - ""En el traspaso, la Gantt de Comercial no conversa con lo que necesitamos realmente." (Felipe Ignacio Bravo Pérez)"

## Relación Con Problemas Similares (Merge)
- `M02`: Fila 7 + Fila 17 - Handover Comercial-Operaciones sin estándar de alcance
- Propuesta de descripción combinada: este problema debe tratarse de forma transversal con las filas relacionadas para evitar soluciones aisladas que trasladen el cuello de botella a otra área.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: inmediatamente después del cierre comercial y antes de ejecución operativa.
- Stack tentativo: **Copilot en Word + SharePoint checklist + Teams review** para “Acta de Alcances Operativos”.
- Automatización: extracción de alcance, supuestos y exclusiones desde oferta hacia formato operativo estándar.
- Licenciamiento foco: estandarización documental para bajar sobretiempo de interpretación en Operaciones.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Naranja Alto (#F57C00)**
- Base de asignación: score actual **4/5** del documento.
- Lectura ejecutiva: Impacto alto multiárea o en un proceso crítico de negocio.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Verde Quick Win (#2E7D32)**
- Ventana tentativa: **1-4 semanas**
- Lectura ejecutiva: Configurable con cambios acotados y mínima integración.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)