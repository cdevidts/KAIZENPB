# Fila 5 - Propuestas técnicas muy extensas y sobreespecificadas

## Ficha Ejecutiva
- Área origen: **Comercial**
- Importancia operacional: **3/5 (Medio-Alto)**
- Indicador de beneficio por resolver (IBO): **60/100**
- Clasificación KAIZEN principal: **Sobreproducción**
- Clasificación KAIZEN secundaria: **Sobreprocesamiento**

## Descripción Del Problema
Propuestas técnicas muy extensas y sobreespecificadas

## Proceso Operacional Afectado
Elaboración de propuestas técnico-comerciales

## Dónde Se Arma El Cuello De Botella
Se genera documentación extensa y heterogénea que no prioriza lo que el cliente realmente decide.

## Subproblemas Detectados
- Riesgo de regalar la receta
- Cliente no lo lee completo
- Propuestas no estandarizadas

## Impacto En La Operación
- Áreas/roles afectados: Comercial, Ingeniería Preventa, Cliente final
- KPI/impacto relevante: Tiempo de preparación elevado; documentos de 40-80+ páginas; riesgo de regalar know-how y bajar tasa de cierre.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- 2.1 Sobrecarga documental (40-80+ páginas) que el cliente no lee
  - ""Por ejemplo, este, un documento, es un documento, si te das cuenta, de casi 40 hojas, a mi parecer, a mi parecer es completamente mejorable porque finalmente el cliente no te lee las 40 hojas." (Andrés Alberto Soto Jaña)"
  - ""Si te das cuenta, hay documentos que, no sé, durante 40 hojas, pero el documento cuando me lo entregaron eran 80, ¿Cachai? Entonces tenía mucha información y los muchachos se demoraron un montón en construirlo." (Andrés Alberto Soto Jaña)"
- 2.2 Riesgo de sobreentregar know-how y facilitar subcotización de terceros
  - ""Hay mucho know how acá, hay mucho conocimiento, hay muchas cosas que tú decís, le estoy dando la receta completa, ¿Cachai? A mí me queda de repente la sensación prácticamente tomate los regalos, ¿Cachai?" (Andrés Alberto Soto Jaña)"
  - ""Para que no pase eso, para que no pase de que el cliente se quede con mucha información y que perfectamente puede pescar el documento Cristóbal, y mandárselo a otro loco, cotízame lo mismo y cóbrame el 15% menos." (Andrés Alberto Soto Jaña)"

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: en la redacción de propuesta técnica antes del envío al cliente.
- Stack tentativo: **Word + SharePoint + M365 Copilot** sobre plantilla corporativa de dos capas (resumen ejecutivo + anexos).
- Automatización: generación asistida de borrador ejecutivo y control de estructura estándar por tipo de oferta.
- Licenciamiento foco: Copilot para autores de propuesta y repositorio versionado de plantillas aprobadas.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Amarillo Medio-Alto (#FBC02D)**
- Base de asignación: score actual **3/5** del documento.
- Lectura ejecutiva: Impacto relevante en un área o flujo clave, con efectos controlables.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Verde Quick Win (#2E7D32)**
- Ventana tentativa: **1-4 semanas**
- Lectura ejecutiva: Configurable con cambios acotados y mínima integración.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)