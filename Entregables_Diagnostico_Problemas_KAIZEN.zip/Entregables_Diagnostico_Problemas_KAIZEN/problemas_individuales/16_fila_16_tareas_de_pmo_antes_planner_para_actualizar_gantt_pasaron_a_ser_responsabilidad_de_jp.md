# Fila 16 - Tareas de PMO (antes Planner) para actualizar Gantt pasaron a ser responsabilidad de JP

## Ficha Ejecutiva
- Área origen: **Operaciones**
- Importancia operacional: **4/5 (Alto)**
- Indicador de beneficio por resolver (IBO): **80/100**
- Clasificación KAIZEN principal: **Talento no utilizado**
- Clasificación KAIZEN secundaria: **Muri + Sobreprocesamiento**

## Descripción Del Problema
Tareas de PMO (antes Planner) para actualizar Gantt pasaron a ser responsabilidad de JP

## Proceso Operacional Afectado
Función de planificación/PMO para mantenimiento de Gantt

## Dónde Se Arma El Cuello De Botella
La eliminación de rol centralizado de PMO transfiere carga de actualización a JPs ya saturados.

## Subproblemas Detectados
- Actualización de Gantt deja de estar centralizada (antes lo hacía PMO/Planner)

## Impacto En La Operación
- Áreas/roles afectados: Operaciones, Ingeniería, Control de Proyecto
- KPI/impacto relevante: Menor disciplina de actualización; menor capacidad de seguimiento transversal del portafolio.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- 8.0 Tareas de PMO (antes planner) para actualizar Gantt pasaron a ser responsabilidad de JP
  - ""Antes se realizaba a través de un planner, pero sabemos que hoy día no." (Hugo Ricardo Jibaja Salas)"

## Relación Con Problemas Similares (Merge)
- `M01`: Fila 2 + Fila 10 + Fila 13 + Fila 16 - Planificación no integrada, Shadow IT y vacío PMO
- Propuesta de descripción combinada: este problema debe tratarse de forma transversal con las filas relacionadas para evitar soluciones aisladas que trasladen el cuello de botella a otra área.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: ciclo semanal de actualización de Gantt y control de portafolio.
- Stack tentativo: **Project Plan 3 + Planner + Power BI** bajo esquema PMO-lite (roles, cadencias, ownership).
- Automatización: recordatorios automáticos de actualización, consolidación de estado y resumen ejecutivo semanal.
- Licenciamiento foco: rol planificador habilitado con herramientas corporativas y tablero de seguimiento común.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Naranja Alto (#F57C00)**
- Base de asignación: score actual **4/5** del documento.
- Lectura ejecutiva: Impacto alto multiárea o en un proceso crítico de negocio.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Naranja Implementación Media (#EF6C00)**
- Ventana tentativa: **9-12 semanas**
- Lectura ejecutiva: Integra múltiples componentes M365/Dynamics + UAT formal.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)