# Fila 4 - CRM desalimentado (fichas de clientes)

## Ficha Ejecutiva
- Área origen: **Comercial**
- Importancia operacional: **3/5 (Medio-Alto)**
- Indicador de beneficio por resolver (IBO): **60/100**
- Clasificación KAIZEN principal: **Defectos**
- Clasificación KAIZEN secundaria: **Talento no utilizado**

## Descripción Del Problema
CRM desalimentado (fichas de clientes)

## Proceso Operacional Afectado
Gestión comercial de cuentas y oportunidades en CRM

## Dónde Se Arma El Cuello De Botella
La ficha cliente no se alimenta en profundidad y el conocimiento queda en la memoria del vendedor.

## Subproblemas Detectados
- Información cualitativa pobre; memoria del cliente no sistematizada
- Invisibilidad de red de decisiones/influencias en CRM; poca documentación del customer journey (dependiente del vendedor)
- Distinguir entre sponsor y cliente final

## Impacto En La Operación
- Áreas/roles afectados: Comercial (CAM), Preventa, Gerencia Comercial
- KPI/impacto relevante: Menor trazabilidad del customer journey; riesgo de pérdida de continuidad comercial ante cambios de personas.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- 1.1 Erosión de la memoria institucional por carga de datos incompleta (fichas pobres)
  - ""El CRM tiene una base de datos, digamos, de todos nuestros clientes, o debería tenerlo. Cliente Cristóbal de todos nuestros clientes a todo nivel. ¿Qué significa todo nivel? Dónde trabaja, inclusive... algo que no está depurado, si está casado, si tiene hijo, en qué lugar viv..."
  - ""Algo que no se ha hecho bien Cristóbal, desde que yo digamos, estoy trabajando en Protagonista y ahora que me hice cargo del área, es algo que hay que mejorar y algo que hay que trabajar el año 2026." (Andrés Alberto Soto Jaña)"
- 1.2 Invisibilidad de la red de decisión e influencia (sponsor vs cliente final) por falta de organigramas
  - ""Entonces ¿Qué falta acá por ejemplo, son los organigramas de las distintas áreas, obviamente que van cambiando la gente de nuestros clientes, para entender que de repente pasa Cristóbal, que dentro de los proyectos, por ejemplo, tú tienes un cliente final y tienes un sponsor,..."
  - ""Yo te pongo el caso mío que es Collaguas, yo tengo dentro de Collaguas y varios sponsors y los otros clientes finales no tienen la menor idea de tecnología, porque son clientes, por ejemplo yo saco agua, el área vegetal saca agua, pero a nivel de tecnología no tienen la menor..."

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: al cambiar etapa de oportunidad en CRM (calificar/desarrollar/proponer).
- Stack tentativo: **Dynamics 365 Sales + Copilot for Sales** para completar ficha, sponsor, cliente final y contexto relacional.
- Automatización: validaciones obligatorias por etapa con **Power Automate** y recordatorios de campos críticos faltantes.
- Licenciamiento foco: mantener CRM como fuente única; Copilot para preparación de reuniones y continuidad comercial.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Amarillo Medio-Alto (#FBC02D)**
- Base de asignación: score actual **3/5** del documento.
- Lectura ejecutiva: Impacto relevante en un área o flujo clave, con efectos controlables.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Amarillo Implementación Corta (#F9A825)**
- Ventana tentativa: **5-8 semanas**
- Lectura ejecutiva: Requiere estandarización de proceso y automatizaciones moderadas.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)