# Fila 18 - Visibilidad tardía de desvíos afecta oportunidades de extensión

## Ficha Ejecutiva
- Área origen: **Operaciones**
- Importancia operacional: **5/5 (Crítico)**
- Indicador de beneficio por resolver (IBO): **100/100**
- Clasificación KAIZEN principal: **Espera**
- Clasificación KAIZEN secundaria: **Defectos + Sobreprocesamiento**

## Descripción Del Problema
Visibilidad tardía de desvíos afecta oportunidades de extensión

## Proceso Operacional Afectado
Gestión de desvíos y generación de extensiones/controles de cambio

## Dónde Se Arma El Cuello De Botella
La evidencia de desvíos queda dispersa en correos y se transforma tarde en reportabilidad ejecutiva.

## Subproblemas Detectados
- Información crítica de desvíos dispersa en correos no estructurados (“No escrito no sirve”)
- Falta de agilidad en reportabilidad por falta de tiempo para control de cambio
- Dificultan identificación clave para extensiones de contratos
- Extensiones entorpecidas por temas de info del personal

## Impacto En La Operación
- Áreas/roles afectados: Operaciones, Comercial, RRHH, Cliente
- KPI/impacto relevante: Pérdida de oportunidades de extensión; reacción tardía; costos extra de reacreditación/administración.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- 10.1 Información crítica de desvíos dispersa en correos no estructurados ("no escrito no sirve")
  - ""Un correo que nos informó a la minera tal día… La única forma… es la trazabilidad: todo respaldado, todo escrito." (Hugo Ricardo Jibaja Salas)"
  - ""Para las mineras… ante la ley solo sirve lo que está en papel, lo hablado no sirve." (Hugo Ricardo Jibaja Salas)"
- 10.2 Falta de agilidad en reportabilidad dificulta control de cambio / extensiones (por tiempo y por datos)
  - ""Si somos capaces de demostrar que no vamos a alcanzar a terminar a la fecha… nacen oportunidades: controles de cambio, extensión del contrato." (Hugo Ricardo Jibaja Salas)"
  - ""Si avisamos tarde… perdemos tiempo y además hay pega administrativa (reacreditación de personal) para la nueva fecha de extensión." (Hugo Ricardo Jibaja Salas)"

## Relación Con Problemas Similares (Merge)
- `M06`: Fila 9 + Fila 14 + Fila 18 - Reportabilidad operativa manual y desvíos tardíos
- Propuesta de descripción combinada: este problema debe tratarse de forma transversal con las filas relacionadas para evitar soluciones aisladas que trasladen el cuello de botella a otra área.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: captura continua de desvíos durante ejecución y antes de comité semanal con cliente.
- Stack tentativo: **Power Automate + SharePoint + Power BI + Copilot Chat** para estructurar desvíos desde correos/reportes.
- Automatización: eventos de desvío con evidencia, alertas tempranas para control de cambio y soporte de extensiones.
- Licenciamiento foco: trazabilidad contractual y visibilidad oportuna de oportunidades de extensión.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Rojo Crítico (#D32F2F)**
- Base de asignación: score actual **5/5** del documento.
- Lectura ejecutiva: Impacto transversal sobre operación completa, margen y caja.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Naranja Implementación Media (#EF6C00)**
- Ventana tentativa: **9-12 semanas**
- Lectura ejecutiva: Integra múltiples componentes M365/Dynamics + UAT formal.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)