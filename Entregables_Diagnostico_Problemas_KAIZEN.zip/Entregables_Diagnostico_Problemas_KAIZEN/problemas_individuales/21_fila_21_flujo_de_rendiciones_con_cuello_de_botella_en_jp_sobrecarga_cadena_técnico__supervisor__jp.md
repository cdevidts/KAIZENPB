# Fila 21 - Flujo de rendiciones con cuello de botella en JP (sobrecarga). Cadena: Técnico → Supervisor → JP → Hugo → Finanzas

## Ficha Ejecutiva
- Área origen: **Recursos Humanos**
- Importancia operacional: **5/5 (Crítico)**
- Indicador de beneficio por resolver (IBO): **100/100**
- Clasificación KAIZEN principal: **Espera**
- Clasificación KAIZEN secundaria: **Inventario (pendientes) + Muri**

## Descripción Del Problema
Flujo de rendiciones con cuello de botella en JP (sobrecarga). Cadena: Técnico → Supervisor → JP → Hugo → Finanzas

## Proceso Operacional Afectado
Rendiciones de gastos y habilitación de finiquitos

## Dónde Se Arma El Cuello De Botella
Cadena de aprobación larga se atasca en JP y explota cuando RRHH necesita cerrar desvinculación.

## Subproblemas Detectados
- Rendiciones atrasadas
- Bloqueo al hacer finiquitos

## Impacto En La Operación
- Áreas/roles afectados: RRHH, Operaciones, Finanzas, Supervisores, Jefes de Proyecto
- KPI/impacto relevante: Rendiciones atrasadas por semanas/meses; bloqueo de finiquitos; riesgo laboral y administrativo.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- RRHH 2.1 Flujo de rendiciones con cuello de botella en JP — Rendiciones atrasadas
  - ""Hemos estado así con un caso una semana… de un señor que tenía rendiciones de hace dos meses, un mes, porque no devolvían." (Mayra Concha Ramos)"
  - ""Como pasa por todo ese flujo, llega un cuello de botella que es tu jefe de proyecto." (Mayra Concha Ramos)"
- RRHH 2.2 Flujo de rendiciones con cuello de botella en JP — Bloqueo al hacer finiquitos
  - ""Para que yo le dé el finiquito… no tiene que tener rendiciones pendientes." (Mayra Concha Ramos)"
  - ""No le puedo pagar finiquito hasta que me aclare si le debemos o no le demos." (Mayra Concha Ramos)"

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: desde entrega de boletas/comprobantes hasta validación final para finiquito.
- Stack tentativo: **Power Apps + Approvals + Power BI** para pipeline de rendiciones con SLA por etapa.
- Automatización: recordatorios, escalamiento por atraso y visibilidad de pendientes envejecidos para RRHH/Finanzas.
- Licenciamiento foco: flujo auditable end-to-end para evitar bloqueo de finiquitos por rendiciones antiguas.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Rojo Crítico (#D32F2F)**
- Base de asignación: score actual **5/5** del documento.
- Lectura ejecutiva: Impacto transversal sobre operación completa, margen y caja.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Naranja Implementación Media (#EF6C00)**
- Ventana tentativa: **9-12 semanas**
- Lectura ejecutiva: Integra múltiples componentes M365/Dynamics + UAT formal.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)