# Fila 20 - Roster manual (20-20)

## Ficha Ejecutiva
- Área origen: **Recursos Humanos**
- Importancia operacional: **4/5 (Alto)**
- Indicador de beneficio por resolver (IBO): **80/100**
- Clasificación KAIZEN principal: **Defectos**
- Clasificación KAIZEN secundaria: **Sobreprocesamiento + Espera**

## Descripción Del Problema
Roster manual (20-20)

## Proceso Operacional Afectado
Cierre mensual de asistencia y planilla (corte 20-20)

## Dónde Se Arma El Cuello De Botella
Roster manual enviado por JP llega con errores y exige validación correctiva con respaldo escaneado.

## Subproblemas Detectados
- Hecho por JP; llega a RRHH con feriados faltantes, mal cálculo de horas extra e inconsistencias
- Deben corregir con libro de asistencia escaneado

## Impacto En La Operación
- Áreas/roles afectados: RRHH, Operaciones, Jefes de Proyecto, Finanzas
- KPI/impacto relevante: Cierre más lento y con correcciones; riesgo de error de remuneración/horas extra.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- RRHH 1.1 Roster manual (20-20) — Deben corregir con libro de asistencia escaneado
  - ""El Rooster es como un Excel donde decimos dónde está nuestro personal por proyecto y qué sistema tiene." (Mayra Concha Ramos)"
  - ""Esta información es súper manual… aparte de esto nos llega el libro de asistencia… nos llega escaneado." (Mayra Concha Ramos)"

## Relación Con Problemas Similares (Merge)
- `M05`: Fila 20 + Fila 24 - Control de asistencia 20-20 con registros tardíos
- Propuesta de descripción combinada: este problema debe tratarse de forma transversal con las filas relacionadas para evitar soluciones aisladas que trasladen el cuello de botella a otra área.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: preparación del corte 20-20 previo a cierre de planilla.
- Stack tentativo: **Power Apps (roster digital) + reglas de negocio + Power Automate** para consolidación hacia RRHH.
- Automatización: validación de feriados/horas extra/campos mínimos antes de envío, con trazabilidad de correcciones.
- Licenciamiento foco: reducir error de cierre y tiempo de reproceso mensual en RRHH.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Naranja Alto (#F57C00)**
- Base de asignación: score actual **4/5** del documento.
- Lectura ejecutiva: Impacto alto multiárea o en un proceso crítico de negocio.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Amarillo Implementación Corta (#F9A825)**
- Ventana tentativa: **5-8 semanas**
- Lectura ejecutiva: Requiere estandarización de proceso y automatizaciones moderadas.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)