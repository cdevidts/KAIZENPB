# Fila 10 - Gantt de Comercial no aterrizado a la operación (lo vendido por lo general se rearma al iniciar el proyecto; *preguntar por mejoras*)

## Ficha Ejecutiva
- Área origen: **Operaciones**
- Importancia operacional: **5/5 (Crítico)**
- Indicador de beneficio por resolver (IBO): **100/100**
- Clasificación KAIZEN principal: **Defectos**
- Clasificación KAIZEN secundaria: **Sobreprocesamiento + Espera**

## Descripción Del Problema
Gantt de Comercial no aterrizado a la operación (lo vendido por lo general se rearma al iniciar el proyecto; *preguntar por mejoras*)

## Proceso Operacional Afectado
Planificación de ejecución en Gantt al inicio y durante operación

## Dónde Se Arma El Cuello De Botella
La Gantt de origen comercial no aterriza a ejecución real (detalle/predecesores), por lo que se rearma desde cero.

## Subproblemas Detectados
- Prioridades y tareas cambian día a día y “no hay tiempo”
- Muchas veces predecesores no conectados fuerzan sobretrabajo en Gantt
- Poco detalle en Gantt de Comercial (rigurosidad en etapas/tareas)

## Impacto En La Operación
- Áreas/roles afectados: Operaciones, Comercial, Ingeniería, Control de Proyecto
- KPI/impacto relevante: Replanificación intensiva; ejemplo canónico de Gantt de 600 líneas con semanas de adaptación.
- Efecto principal: menor capacidad de control preventivo y mayor retrabajo operativo/administrativo.

## Evidencia Cualitativa (Matriz + Entrevistas)
- 2.1 Prioridades y tareas cambian día a día y "no hay tiempo"
  - ""Las prioridades y las tareas van cambiando día a día y después uno dice: no hay tiempo, no hay tiempo." (Hugo Ricardo Jibaja Salas)"
- 2.2 Predecesores no conectados fuerzan sobretrabajo en Gantt
  - ""A veces no vienen los predecesores, no están conectados y eso te cambia todo para adelante cuando actualizas la fecha." (Hugo Ricardo Jibaja Salas)"
- 2.3 Poco detalle en Gantt de comercial (rigurosidad en etapas/tareas)
  - ""La Gantt que viene de comercial no condice con la real operación en terreno." (Hugo Ricardo Jibaja Salas)"
  - ""Comercial utiliza una estructura que tienen hace años, nunca la han modificado; la carta Gantt no tiene nada que ver con lo que necesitamos realmente." (Felipe Ignacio Bravo Pérez)"

## Relación Con Problemas Similares (Merge)
- `M01`: Fila 2 + Fila 10 + Fila 13 + Fila 16 - Planificación no integrada, Shadow IT y vacío PMO
- Propuesta de descripción combinada: este problema debe tratarse de forma transversal con las filas relacionadas para evitar soluciones aisladas que trasladen el cuello de botella a otra área.

## Solución Tentativa Microsoft (Pre-Estudio Técnico)
- Inserción en flujo: transición preventa→ejecución y replanificación semanal de obra.
- Stack tentativo: **Project Plan 3** como estándar único de Gantt (línea base + predecesores + recursos) con tablero en Power BI.
- Automatización: versión baseline heredable desde Comercial a Operaciones y alertas de impacto por cambios de secuencia.
- Licenciamiento foco: Project Plan 3 en roles de planificación y disciplina PMO-lite para control transversal.
- Enfoque de despliegue recomendado: **M365-first**, piloto por Wave de 90 días con KPIs (OTD, retrabajo, lead time, $ externo) y criterio Go/No-Go.

## Semáforo De Gravedad
- Color asignado: **Rojo Crítico (#D32F2F)**
- Base de asignación: score actual **5/5** del documento.
- Lectura ejecutiva: Impacto transversal sobre operación completa, margen y caja.

## Semáforo De Tiempo De Implementación Tentativa
- Color asignado: **Rojo Implementación Extendida (#C62828)**
- Ventana tentativa: **13-20 semanas**
- Lectura ejecutiva: Cambio estructural multiárea con integración profunda y gestión del cambio.

## Lectura Pre-Implementación
- El problema está suficientemente definido para diseñar iniciativa piloto, pero antes de implementación se recomienda medir línea base (tiempo actual, tasa de error, frecuencia, impacto en cierre mensual/proyecto).

## Fuentes
- Transformación IA/Nueva_Matriz_actualizada.xlsx (Hoja1, filas 2-24)
- Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf
- Transformación IA/Transformación IA/RESUMEN ENTREVISTAS.pdf
- Transformación IA/working/Entrevistas/* (transcripciones por área)