# Prompt optimizado para diagnóstico pre-implementación (usado en esta ejecución)

Actúa como consultor senior de transformación operacional + IA en etapa de diagnóstico pre-implementación.

## Objetivo
Generar un paquete completo de diagnóstico profesional para PROTAB, asegurando cobertura total de cada problema identificado en `Nueva_Matriz_actualizada.xlsx`.

## Fuentes obligatorias (lectura completa y cruzada)
1. Matriz principal: `Transformación IA/Nueva_Matriz_actualizada.xlsx`
2. Contexto canónico: `Transformación IA/PROTAB_Documento_Contexto_Canonico.pdf`
3. Entrevistas y evidencia operativa en: `Transformación IA/Transformación IA` (incluyendo subcarpetas, zip, transcripciones, reportes y anexos relevantes).

## Reglas de trabajo
1. Para cada fila/problema de la matriz, leer TODAS las columnas con contenido antes de redactar.
2. Cruzar cada problema con evidencia del contexto canónico y entrevistas para entender proceso real, fricción inter-áreas y efecto operacional.
3. Detectar problemas equivalentes entre áreas (mismo problema expresado por actores distintos).
4. Mantener trazabilidad explícita fila → documento para evitar omisiones.
5. Al final, revalidar contra la matriz que ningún problema se pierda.

## Entregables requeridos
### A) Diagnósticos individuales
- Generar 23 documentos (uno por fila/problema de la matriz).
- Cada documento debe incluir:
  - Título del problema (alineado a la fila)
  - Área(s) afectada(s)
  - Descripción ejecutiva del problema
  - Proceso operacional detallado (cómo funciona hoy)
  - Punto exacto del cuello de botella
  - Subproblemas (desglose completo)
  - Impacto: operativo, financiero y organizacional
  - Afectados (roles/áreas)
  - KPI/horas perdidas o métrica relevante (dato o estimación razonada)
  - Evidencia de entrevistas/documentos
  - Calificación de importancia para la operación (indicador de beneficio al resolver)
  - Clasificación KAIZEN (desperdicio principal y secundario)

### B) Diagnósticos combinados (merged)
- Crear documentos adicionales para problemas equivalentes entre áreas.
- El título del documento merged debe explicitar las filas combinadas.
- Incluir propuesta de redacción unificada del problema y alcance transversal.
- En cada documento individual involucrado, mencionar su vínculo al merged correspondiente.

### C) Resumen KAIZEN consolidado
- Listar todos los problemas por título de documento + clasificación KAIZEN.
- Entregar resumen métrico por cantidad de problemas por categoría KAIZEN.
- Priorizar acciones sugeridas para avanzar en mejora continua (quick wins, mediano plazo, estructural).

## Criterios de calidad
- Redacción profesional, clara y accionable.
- Nivel de detalle suficiente para que un tercero comprenda la operación y el problema sin contexto adicional.
- Evitar recomendaciones de implementación técnica profunda; enfocarse en diagnóstico robusto y priorización pre-implementación.
- Garantizar consistencia terminológica y trazabilidad completa.
