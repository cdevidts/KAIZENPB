# Glosa Mapa De Colores

## 1) Semáforo De Gravedad (Basado en score)
- Score 5: **Rojo Crítico (#D32F2F)** -> Impacto transversal sobre operación completa, margen y caja.
- Score 4: **Naranja Alto (#F57C00)** -> Impacto alto multiárea o en proceso crítico.
- Score 3: **Amarillo Medio-Alto (#FBC02D)** -> Impacto relevante en un área/flujo clave.
- Score 2: **Verde Medio (#388E3C)** -> Impacto acotado y manejable.
- Score 1: **Azul Bajo (#1976D2)** -> Impacto micro/habilitador.

## 2) Semáforo De Tiempo De Implementación Tentativa
- **Verde Quick Win (#2E7D32)**: 1-4 semanas. Ajustes rápidos, baja fricción técnica.
- **Amarillo Implementación Corta (#F9A825)**: 5-8 semanas. Requiere estandarizar + automatizar.
- **Naranja Implementación Media (#EF6C00)**: 9-12 semanas. Integración entre sistemas y UAT.
- **Rojo Implementación Extendida (#C62828)**: 13-20 semanas. Transformación estructural.

## Nota Ejecutiva
- El color de gravedad responde a impacto de negocio (qué tan doloroso es no resolverlo).
- El color de implementación responde a esfuerzo/plazo de ejecución (qué tan complejo es resolverlo).
- Ambos semáforos deben leerse juntos para priorizar portafolio (impacto vs esfuerzo).