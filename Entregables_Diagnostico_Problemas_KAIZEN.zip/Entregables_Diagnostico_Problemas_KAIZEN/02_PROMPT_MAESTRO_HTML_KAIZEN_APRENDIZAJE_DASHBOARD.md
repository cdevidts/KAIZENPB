# Prompt Maestro Reescrito - Web Kaizen Navegable (Aprendizaje + Dashboard + Problemas + Merges)

Actúa como **arquitecto Full-Stack senior + consultor Kaizen + diseñador de información ejecutiva**.

Tu misión es construir una **web HTML navegable, estática y offline** usando **todos los archivos** de esta carpeta y subcarpetas:

`/home/cdevidts/PROTAB/Planificacion Transformacion IA/Transformación IA/Entregables_Diagnostico_Problemas_KAIZEN`

## Objetivo de negocio
Crear una plataforma que sirva simultáneamente como:
1. **Página de aprendizaje Kaizen** (didáctica, clara, con glosario y criterios de análisis usados en este diagnóstico).
2. **Dashboard ejecutivo** con métricas, filtros y trazabilidad de problemas.
3. **Repositorio navegable de todos los problemas**.
4. **Repositorio navegable de merges** que explique consolidaciones y equivalencias estructurales.

## Menú principal obligatorio
- `Aprendizaje Kaizen`
- `Dashboard Kaizen`
- `Todos los problemas`
- `Merges`

## Fuentes obligatorias (leer y usar todas)
- `Resumen_KAIZEN_Consolidado.md`
- `Trazabilidad_Filas_23.csv`
- `Glosa_Mapa_Colores.md`
- `problemas_individuales/*.md` (23)
- `problemas_merged/*.md` (7)
- `Resumen_KAIZEN_Consolidado.html` (referencia visual/estructura exportable)

## Restricciones de implementación
- Sitio **100% offline** (sin CDN ni APIs externas).
- No inventar datos; todo debe ser trazable a fuente.
- Idioma: español.
- Responsive (desktop + móvil).
- Accesibilidad base (estructura semántica, foco visible, contrastes legibles).

## Requisito crítico de páginas de detalle
Las páginas individuales y de merges deben ser **idénticas al contenido exportable HTML** de cada archivo Markdown fuente.
- Cada problema individual debe tener su propia página HTML renderizada desde su `.md`.
- Cada merge debe tener su propia página HTML renderizada desde su `.md`.
- Desde dashboard/listados, al hacer click se debe abrir esa página de detalle exportada.
- No resumir ni recortar el contenido del detalle.

## Requisitos funcionales por sección

### 1) Aprendizaje Kaizen
Debe enseñar, con enfoque aplicado al caso PROTAB:
- Kaizen en contexto operacional.
- Muda, Mura, Muri.
- Categorías KAIZEN usadas en este diagnóstico.
- Cómo se aplicó el criterio de clasificación en los problemas.
- Diagramas explicativos (flujo de clasificación, origen de evidencia, relación problema-impacto).
- Glosario técnico-operacional y términos del diagnóstico.

### 2) Dashboard Kaizen
Debe incluir:
- KPIs globales (total problemas, total merges, cobertura, distribución por área y categoría).
- Gráficas variadas (no solo un tipo): barras, dona/pie, comparativas.
- Filtros combinables por área, categoría, importancia, merge, color de gravedad y color de tiempo.
- Tabla/listado clickeable de problemas con nombre corto explicativo.

#### Glosa de colores obligatoria dentro del dashboard
Integrar explícitamente la glosa usada (desde `Glosa_Mapa_Colores.md`) y mostrarla en el mismo dashboard con:
1. **Glosa de color por impacto/gravedad** (score -> color).
2. **Glosa de color por tiempo de implementación** (quick win -> estructural).

#### Gráficas obligatorias de glosas
Agregar gráficas para:
- Distribución de problemas por **color de impacto/gravedad**.
- Distribución de problemas por **color de tiempo de implementación**.
- Distribución de merges por **color de impacto/gravedad**.
- Distribución de merges por **color de tiempo de implementación**.

### 3) Todos los problemas
- Listado completo de los 23 problemas.
- Mostrar: nombre corto, área, KAIZEN principal, importancia, color de gravedad, color de tiempo, merge asociado.
- Búsqueda por texto + filtros.
- Click en nombre -> página HTML exportada del problema.

### 4) Merges
- Listado completo de los 7 merges.
- Mostrar: filas combinadas, áreas involucradas, KAIZEN dominante, color de gravedad, color de tiempo.
- Explicar por qué se consolidan (mismo problema estructural).
- Links bidireccionales merge <-> problemas involucrados.
- Click en merge -> página HTML exportada del merge.

## Validaciones obligatorias de consistencia
Validar y reportar explícitamente:
- Problemas individuales: 23.
- Merges: 7.
- Conteo por categoría KAIZEN:
  - Defectos: 7
  - Sobreprocesamiento: 4
  - Espera: 4
  - Movimiento: 3
  - Transporte/Traspasos: 2
  - Talento no utilizado: 2
  - Sobreproducción: 1
- Conteo por área:
  - Operaciones: 11
  - Comercial: 5
  - Recursos Humanos: 5
  - Ingeniería: 2

Si hay discrepancias, detener y mostrar qué archivo/campo no cuadra.

## Criterio de calidad visual
- Diseño ejecutivo-profesional, limpio y legible.
- Sistema de color consistente entre dashboard y glosas.
- Jerarquía tipográfica clara.
- Navegación simple y rápida (sin fricción).
- Tablas y gráficos con lectura inmediata.

## Entregables finales
1. Sitio HTML navegable completo.
2. Script reproducible de build (data + páginas).
3. Páginas de detalle exportadas (23 individuales + 7 merges).
4. README corto de uso local.
5. Resumen final con archivos creados/modificados y validaciones superadas.
