import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const baseDir = path.resolve(__dirname, '..');

const buildScript = path.join(baseDir, 'scripts', 'build_kaizen_web.mjs');
const sourceDir = path.join(baseDir, 'kaizen_web');
const targetDir = path.join(baseDir, 'public_site');

const build = spawnSync('node', [buildScript], {
  cwd: baseDir,
  stdio: 'inherit',
});

if (build.status !== 0) {
  process.exit(build.status ?? 1);
}

fs.rmSync(targetDir, { recursive: true, force: true });
fs.mkdirSync(targetDir, { recursive: true });
fs.cpSync(sourceDir, targetDir, { recursive: true });

const nojekyll = path.join(targetDir, '.nojekyll');
if (!fs.existsSync(nojekyll)) {
  fs.writeFileSync(nojekyll, '', 'utf8');
}

console.log(`Deploy package listo en: ${targetDir}`);
