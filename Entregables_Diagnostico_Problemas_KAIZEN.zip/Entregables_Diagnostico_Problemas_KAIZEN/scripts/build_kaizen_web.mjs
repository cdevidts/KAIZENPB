import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const baseDir = path.resolve(__dirname, '..');

const paths = {
  resumenMd: path.join(baseDir, 'Resumen_KAIZEN_Consolidado.md'),
  trazabilidadCsv: path.join(baseDir, 'Trazabilidad_Filas_23.csv'),
  glosaMd: path.join(baseDir, 'Glosa_Mapa_Colores.md'),
  problemasDir: path.join(baseDir, 'problemas_individuales'),
  mergesDir: path.join(baseDir, 'problemas_merged'),
  outputDir: path.join(baseDir, 'kaizen_web'),
  outAssetsDir: path.join(baseDir, 'kaizen_web', 'assets'),
  outDetailProblemasDir: path.join(baseDir, 'kaizen_web', 'detalle', 'problemas'),
  outDetailMergesDir: path.join(baseDir, 'kaizen_web', 'detalle', 'merges'),
};

const EXPECTED = {
  totalProblemas: 23,
  totalMerges: 7,
  kaizen: {
    Defectos: 7,
    Sobreprocesamiento: 4,
    Espera: 4,
    Movimiento: 3,
    'Transporte/Traspasos': 2,
    'Talento no utilizado': 2,
    Sobreproduccion: 1,
  },
  areas: {
    Operaciones: 11,
    Comercial: 5,
    'Recursos Humanos': 5,
    Ingenieria: 2,
  },
};

function readText(filePath) {
  return fs.readFileSync(filePath, 'utf8');
}

function safeMkdir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function normalizeForCompare(text) {
  return text
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function parseCsvRows(csvText) {
  const lines = csvText
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  if (lines.length < 2) {
    throw new Error('CSV de trazabilidad sin contenido');
  }

  const dataLines = lines.slice(1);
  return dataLines.map((line) => {
    const parts = line.split(',');
    if (parts.length < 7) {
      throw new Error(`Linea CSV invalida: ${line}`);
    }

    return {
      fila: Number(parts[0]),
      area: parts[1].trim(),
      problema: parts.slice(2, parts.length - 4).join(',').trim(),
      documento_individual: parts[parts.length - 4].trim(),
      kaizen: parts[parts.length - 3].trim(),
      importancia: Number(parts[parts.length - 2]),
      merged_ids: parts[parts.length - 1].trim(),
    };
  });
}

function extractHeadingLevel1(markdown) {
  const match = markdown.match(/^#\s+(.+)$/m);
  return match ? match[1].trim() : '';
}

function extractSection(markdown, sectionTitle) {
  const escaped = sectionTitle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp(`##\\s+${escaped}\\n([\\s\\S]*?)(?=\\n##\\s+|$)`, 'm');
  const match = markdown.match(re);
  return match ? match[1].trim() : '';
}

function extractValue(sectionText, pattern, fallback = '') {
  const match = sectionText.match(pattern);
  return match ? match[1].trim() : fallback;
}

function parseColorToken(token) {
  const clean = token.replace(/\*\*/g, '').trim();
  const hexMatch = clean.match(/(#[0-9A-Fa-f]{6})/);
  const hex = hexMatch ? hexMatch[1].toUpperCase() : '';
  const label = clean.replace(/\(#[0-9A-Fa-f]{6}\)/i, '').trim();
  return { label, hex };
}

function sanitizeShortName(rawProblem) {
  return rawProblem
    .replace(/^\d+\.\s*/, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function sortedFiles(dirPath) {
  return fs
    .readdirSync(dirPath)
    .filter((name) => name.toLowerCase().endsWith('.md'))
    .sort((a, b) => a.localeCompare(b, 'es'));
}

function toCountMap(items, keySelector) {
  const map = {};
  for (const item of items) {
    const key = keySelector(item);
    map[key] = (map[key] || 0) + 1;
  }
  return map;
}

function compareExpectedMap(actualMap, expectedMap, label) {
  const expectedKeys = Object.keys(expectedMap);
  for (const key of expectedKeys) {
    const expectedVal = expectedMap[key];
    let actualVal = 0;

    for (const actualKey of Object.keys(actualMap)) {
      if (normalizeForCompare(actualKey) === normalizeForCompare(key)) {
        actualVal = actualMap[actualKey];
        break;
      }
    }

    if (actualVal !== expectedVal) {
      throw new Error(
        `Validacion fallida en ${label}: ${key} esperado=${expectedVal}, actual=${actualVal}`
      );
    }
  }
}

function runQuartoPandoc(inputPath, outputPath) {
  const result = spawnSync(
    'quarto',
    ['pandoc', inputPath, '--standalone', '--to', 'html', '--output', outputPath],
    { encoding: 'utf8' }
  );

  if (result.status !== 0) {
    throw new Error(
      `Error exportando HTML (${inputPath}):\n${result.stderr || result.stdout}`
    );
  }
}

function createSiteStyles() {
  return `:root {
  --bg: #f7f9fb;
  --card: #ffffff;
  --text: #1f2937;
  --muted: #5f6b7a;
  --line: #d6dde6;
  --accent: #0b5d7a;
  --accent-soft: #e6f4f8;
}

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: "Segoe UI", "Calibri", "Helvetica Neue", Arial, sans-serif;
  background: radial-gradient(circle at top right, #d9edf4 0%, #f7f9fb 45%);
  color: var(--text);
}

a {
  color: #0a4f8a;
  text-decoration: none;
}

a:hover {
  text-decoration: underline;
}

header {
  background: linear-gradient(120deg, #0b5d7a 0%, #1f7a8c 100%);
  color: white;
  padding: 1.2rem 1rem 0.9rem;
  border-bottom: 1px solid rgba(255,255,255,0.2);
}

.header-inner {
  max-width: 1200px;
  margin: 0 auto;
}

h1 {
  margin: 0 0 0.6rem;
  font-size: 1.35rem;
}

nav {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  padding-bottom: 0.3rem;
}

nav a {
  color: white;
  border: 1px solid rgba(255,255,255,0.35);
  border-radius: 8px;
  padding: 0.35rem 0.6rem;
  font-size: 0.92rem;
}

nav a.active {
  background: rgba(255,255,255,0.2);
  border-color: white;
}

main {
  max-width: 1200px;
  margin: 1rem auto 1.6rem;
  padding: 0 1rem;
}

.card {
  background: var(--card);
  border: 1px solid var(--line);
  border-radius: 12px;
  padding: 0.95rem;
  margin-bottom: 0.9rem;
}

.grid {
  display: grid;
  gap: 0.85rem;
}

.grid.kpi {
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
}

.grid.two {
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
}

.kpi-box {
  border: 1px solid var(--line);
  border-radius: 10px;
  padding: 0.75rem;
  background: #fff;
}

.kpi-label {
  color: var(--muted);
  font-size: 0.83rem;
}

.kpi-value {
  font-size: 1.45rem;
  font-weight: 700;
  margin-top: 0.2rem;
}

.controls {
  display: grid;
  gap: 0.7rem;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
}

input[type="search"],
select {
  width: 100%;
  border: 1px solid #b9c5d3;
  border-radius: 8px;
  padding: 0.42rem 0.5rem;
  background: white;
}

table {
  width: 100%;
  border-collapse: collapse;
}

th,
td {
  border-bottom: 1px solid #e3e8ef;
  text-align: left;
  padding: 0.45rem;
  font-size: 0.9rem;
  vertical-align: top;
}

th {
  background: #f2f6fb;
}

.color-pill {
  display: inline-flex;
  align-items: center;
  gap: 0.42rem;
  border: 1px solid #d8e0ea;
  border-radius: 999px;
  padding: 0.2rem 0.55rem;
  font-size: 0.82rem;
  background: #fff;
}

.dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  display: inline-block;
  border: 1px solid rgba(0,0,0,0.08);
}

.legend-list {
  display: grid;
  gap: 0.5rem;
}

.legend-item {
  border: 1px solid #d9e0e8;
  border-radius: 10px;
  padding: 0.55rem;
  background: #fff;
}

.chart-box {
  border: 1px solid #dce4ee;
  border-radius: 10px;
  padding: 0.6rem;
}

.chart-title {
  margin: 0 0 0.5rem;
  font-size: 0.95rem;
}

.bar-row {
  display: grid;
  grid-template-columns: 190px 1fr 52px;
  gap: 0.45rem;
  align-items: center;
  margin: 0.35rem 0;
  font-size: 0.86rem;
}

.bar-track {
  height: 13px;
  background: #edf2f7;
  border-radius: 7px;
  overflow: hidden;
}

.bar-fill {
  height: 100%;
}

.donut-wrap {
  display: grid;
  grid-template-columns: 180px 1fr;
  gap: 0.8rem;
  align-items: center;
}

.donut-legend {
  display: grid;
  gap: 0.28rem;
  font-size: 0.83rem;
}

.card-list {
  display: grid;
  gap: 0.65rem;
}

.merge-card {
  border: 1px solid #d8e1eb;
  border-radius: 10px;
  padding: 0.65rem;
  background: #fff;
}

.small {
  color: var(--muted);
  font-size: 0.84rem;
}

.flow {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 0.6rem;
  margin-top: 0.6rem;
}

.flow-step {
  border: 1px solid #cfe0eb;
  border-left: 5px solid var(--accent);
  border-radius: 8px;
  padding: 0.55rem;
  background: #fcfeff;
}

@media (max-width: 900px) {
  .bar-row {
    grid-template-columns: 1fr;
    gap: 0.2rem;
  }

  .donut-wrap {
    grid-template-columns: 1fr;
  }

  table {
    display: block;
    overflow-x: auto;
    white-space: nowrap;
  }
}`;
}

function createBaseHtml({ pageId, pageTitle, heading, lead, bodyMarkup }) {
  return `<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>${pageTitle}</title>
  <link rel="stylesheet" href="assets/styles.css" />
</head>
<body data-page="${pageId}">
  <header>
    <div class="header-inner">
      <h1>PROTAB · Plataforma Kaizen</h1>
      <nav>
        <a data-nav="aprendizaje" href="aprendizaje-kaizen.html">Aprendizaje Kaizen</a>
        <a data-nav="dashboard" href="dashboard-kaizen.html">Dashboard Kaizen</a>
        <a data-nav="problemas" href="todos-los-problemas.html">Todos los problemas</a>
        <a data-nav="merges" href="merges.html">Merges</a>
      </nav>
    </div>
  </header>
  <main>
    <section class="card">
      <h2>${heading}</h2>
      <p class="small">${lead}</p>
    </section>
    ${bodyMarkup}
  </main>
  <script src="assets/data.js"></script>
  <script src="assets/app.js"></script>
</body>
</html>`;
}

function buildAppJs() {
  return `const PAGE = document.body.dataset.page;

const NAV_MAP = {
  home: 'dashboard',
  aprendizaje: 'aprendizaje',
  dashboard: 'dashboard',
  problemas: 'problemas',
  merges: 'merges',
};

async function boot() {
  const navKey = NAV_MAP[PAGE] || 'dashboard';
  document.querySelectorAll('nav a').forEach((el) => {
    if (el.dataset.nav === navKey) el.classList.add('active');
  });

  if (PAGE === 'home') return;

  let data = null;
  try {
    const resp = await fetch('assets/data.json');
    if (!resp.ok) throw new Error('No se pudo leer assets/data.json');
    data = await resp.json();
  } catch (_) {
    data = window.KAIZEN_DATA || null;
  }

  if (!data) {
    throw new Error('No se pudo cargar data.json ni data.js');
  }

  if (PAGE === 'aprendizaje') renderAprendizaje(data);
  if (PAGE === 'dashboard') renderDashboard(data);
  if (PAGE === 'problemas') renderProblemas(data);
  if (PAGE === 'merges') renderMerges(data);
}

function htmlEscape(text) {
  return String(text)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function colorPill(label, hex) {
  return '<span class="color-pill"><span class="dot" style="background:' + hex + '"></span>' + htmlEscape(label) + '</span>';
}

function renderBarChart(targetEl, dataItems, title) {
  const max = Math.max(...dataItems.map((d) => d.value), 1);
  const rows = dataItems
    .map((d) => {
      const pct = Math.round((d.value / max) * 100);
      return '<div class="bar-row">' +
        '<div>' + htmlEscape(d.label) + '</div>' +
        '<div class="bar-track"><div class="bar-fill" style="width:' + pct + '%;background:' + (d.color || '#2c7da0') + '"></div></div>' +
        '<div><strong>' + d.value + '</strong></div>' +
      '</div>';
    })
    .join('');

  targetEl.innerHTML = '<div class="chart-box"><h4 class="chart-title">' + htmlEscape(title) + '</h4>' + rows + '</div>';
}

function renderDonutChart(targetEl, dataItems, title) {
  const total = dataItems.reduce((acc, item) => acc + item.value, 0) || 1;
  let offset = 0;
  const radius = 54;
  const circumference = 2 * Math.PI * radius;

  const circles = dataItems
    .map((item) => {
      const frac = item.value / total;
      const len = frac * circumference;
      const circle = '<circle cx="70" cy="70" r="54" fill="none" stroke="' + (item.color || '#2c7da0') + '" stroke-width="20" stroke-dasharray="' + len.toFixed(2) + ' ' + circumference.toFixed(2) + '" stroke-dashoffset="-' + offset.toFixed(2) + '"></circle>';
      offset += len;
      return circle;
    })
    .join('');

  const legend = dataItems
    .map((item) => '<div>' + colorPill(item.label + ' (' + item.value + ')', item.color || '#2c7da0') + '</div>')
    .join('');

  targetEl.innerHTML = '<div class="chart-box"><h4 class="chart-title">' + htmlEscape(title) + '</h4>' +
    '<div class="donut-wrap">' +
      '<svg viewBox="0 0 140 140" width="180" height="180" role="img" aria-label="' + htmlEscape(title) + '">' +
        '<circle cx="70" cy="70" r="54" fill="none" stroke="#ebeff4" stroke-width="20"></circle>' +
        circles +
        '<text x="70" y="74" text-anchor="middle" font-size="16" font-weight="700">' + total + '</text>' +
      '</svg>' +
      '<div class="donut-legend">' + legend + '</div>' +
    '</div>' +
  '</div>';
}

function makeProblemRow(problem) {
  const mergeLabel = problem.mergeId ? '<a href="merges.html#' + encodeURIComponent(problem.mergeId) + '">' + problem.mergeId + '</a>' : 'Sin merge';
  return '<tr>' +
    '<td><a href="' + problem.detailHtml + '">' + htmlEscape(problem.shortName) + '</a></td>' +
    '<td>' + htmlEscape(problem.area) + '</td>' +
    '<td>' + htmlEscape(problem.kaizen) + '</td>' +
    '<td>' + problem.importancia + '/5</td>' +
    '<td>' + colorPill(problem.gravedad.label, problem.gravedad.hex) + '</td>' +
    '<td>' + colorPill(problem.tiempo.label, problem.tiempo.hex) + '</td>' +
    '<td>' + mergeLabel + '</td>' +
  '</tr>';
}

function filterProblems(problems, ui) {
  const text = ui.search.value.trim().toLowerCase();
  const area = ui.area.value;
  const kaizen = ui.kaizen.value;
  const importancia = ui.importancia.value;
  const mergeMode = ui.merge.value;
  const gravedad = ui.gravedad.value;
  const tiempo = ui.tiempo.value;

  return problems.filter((p) => {
    if (text && ![p.shortName, p.title, p.area, p.kaizen].join(' ').toLowerCase().includes(text)) return false;
    if (area && p.area !== area) return false;
    if (kaizen && p.kaizen !== kaizen) return false;
    if (importancia && String(p.importancia) !== importancia) return false;
    if (mergeMode === 'con' && !p.mergeId) return false;
    if (mergeMode === 'sin' && p.mergeId) return false;
    if (gravedad && p.gravedad.label !== gravedad) return false;
    if (tiempo && p.tiempo.label !== tiempo) return false;
    return true;
  });
}

function renderAprendizaje(data) {
  document.getElementById('aprendizaje-metricas').innerHTML =
    '<div class="grid kpi">' +
      '<div class="kpi-box"><div class="kpi-label">Problemas analizados</div><div class="kpi-value">' + data.summary.totalProblemas + '</div></div>' +
      '<div class="kpi-box"><div class="kpi-label">Merges analizados</div><div class="kpi-value">' + data.summary.totalMerges + '</div></div>' +
      '<div class="kpi-box"><div class="kpi-label">Categorias Kaizen aplicadas</div><div class="kpi-value">' + data.summary.kaizenCounts.length + '</div></div>' +
      '<div class="kpi-box"><div class="kpi-label">Areas cubiertas</div><div class="kpi-value">' + data.summary.areaCounts.length + '</div></div>' +
    '</div>';

  document.getElementById('kaizen-categorias').innerHTML = data.summary.kaizenCounts
    .map((k) => '<div class="legend-item"><strong>' + htmlEscape(k.label) + '</strong><div class="small">Problemas clasificados: ' + k.value + '</div></div>')
    .join('');

  document.getElementById('glosa-impacto').innerHTML = data.glosa.gravedad
    .map((item) => '<div class="legend-item">' + colorPill(item.label, item.hex) + '<div class="small">' + htmlEscape(item.description) + '</div></div>')
    .join('');

  document.getElementById('glosa-tiempo').innerHTML = data.glosa.tiempo
    .map((item) => '<div class="legend-item">' + colorPill(item.label, item.hex) + '<div class="small">' + htmlEscape(item.description) + '</div></div>')
    .join('');
}

function renderDashboard(data) {
  document.getElementById('dash-kpis').innerHTML =
    '<div class="grid kpi">' +
      '<div class="kpi-box"><div class="kpi-label">Total problemas</div><div class="kpi-value">' + data.summary.totalProblemas + '</div></div>' +
      '<div class="kpi-box"><div class="kpi-label">Total merges</div><div class="kpi-value">' + data.summary.totalMerges + '</div></div>' +
      '<div class="kpi-box"><div class="kpi-label">Cobertura matriz</div><div class="kpi-value">100%</div></div>' +
      '<div class="kpi-box"><div class="kpi-label">Importancia promedio</div><div class="kpi-value">' + data.summary.importanciaPromedio.toFixed(2) + '/5</div></div>' +
    '</div>';

  renderBarChart(document.getElementById('chart-kaizen'), data.summary.kaizenCounts, 'Distribucion por categoria Kaizen');
  renderBarChart(document.getElementById('chart-areas'), data.summary.areaCounts, 'Distribucion por area');
  renderDonutChart(document.getElementById('chart-gravedad-prob'), data.summary.gravedadProblemas, 'Problemas por color de impacto/gravedad');
  renderDonutChart(document.getElementById('chart-tiempo-prob'), data.summary.tiempoProblemas, 'Problemas por color de tiempo de implementacion');
  renderBarChart(document.getElementById('chart-gravedad-merge'), data.summary.gravedadMerges, 'Merges por color de impacto/gravedad');
  renderBarChart(document.getElementById('chart-tiempo-merge'), data.summary.tiempoMerges, 'Merges por color de tiempo de implementacion');

  document.getElementById('dashboard-glosa-impacto').innerHTML = data.glosa.gravedad
    .map((item) => '<div class="legend-item">' + colorPill(item.label, item.hex) + '<div class="small">' + htmlEscape(item.description) + '</div></div>')
    .join('');

  document.getElementById('dashboard-glosa-tiempo').innerHTML = data.glosa.tiempo
    .map((item) => '<div class="legend-item">' + colorPill(item.label, item.hex) + '<div class="small">' + htmlEscape(item.description) + '</div></div>')
    .join('');

  const controls = {
    search: document.getElementById('f-search'),
    area: document.getElementById('f-area'),
    kaizen: document.getElementById('f-kaizen'),
    importancia: document.getElementById('f-importancia'),
    merge: document.getElementById('f-merge'),
    gravedad: document.getElementById('f-gravedad'),
    tiempo: document.getElementById('f-tiempo'),
  };

  const option = (value) => '<option value="' + htmlEscape(value) + '">' + htmlEscape(value) + '</option>';

  controls.area.innerHTML = '<option value="">Todas</option>' + data.summary.areaCounts.map((a) => option(a.label)).join('');
  controls.kaizen.innerHTML = '<option value="">Todas</option>' + data.summary.kaizenCounts.map((k) => option(k.label)).join('');
  controls.importancia.innerHTML = '<option value="">Todas</option><option value="5">5</option><option value="4">4</option><option value="3">3</option><option value="2">2</option><option value="1">1</option>';
  controls.gravedad.innerHTML = '<option value="">Todos</option>' + data.summary.gravedadProblemas.map((c) => option(c.label)).join('');
  controls.tiempo.innerHTML = '<option value="">Todos</option>' + data.summary.tiempoProblemas.map((c) => option(c.label)).join('');

  const renderTable = () => {
    const filtered = filterProblems(data.problemas, controls);
    document.getElementById('tabla-problemas').innerHTML = filtered.map(makeProblemRow).join('');
    document.getElementById('resultado-filtro').textContent = filtered.length + ' problemas visibles';
  };

  Object.values(controls).forEach((el) => el.addEventListener('input', renderTable));
  renderTable();
}

function renderProblemas(data) {
  const controls = {
    search: document.getElementById('p-search'),
    area: document.getElementById('p-area'),
    kaizen: document.getElementById('p-kaizen'),
    importancia: document.getElementById('p-importancia'),
    merge: document.getElementById('p-merge'),
    gravedad: document.getElementById('p-gravedad'),
    tiempo: document.getElementById('p-tiempo'),
  };

  const option = (value) => '<option value="' + htmlEscape(value) + '">' + htmlEscape(value) + '</option>';

  controls.area.innerHTML = '<option value="">Todas</option>' + data.summary.areaCounts.map((a) => option(a.label)).join('');
  controls.kaizen.innerHTML = '<option value="">Todas</option>' + data.summary.kaizenCounts.map((k) => option(k.label)).join('');
  controls.importancia.innerHTML = '<option value="">Todas</option><option value="5">5</option><option value="4">4</option><option value="3">3</option><option value="2">2</option><option value="1">1</option>';
  controls.gravedad.innerHTML = '<option value="">Todos</option>' + data.summary.gravedadProblemas.map((c) => option(c.label)).join('');
  controls.tiempo.innerHTML = '<option value="">Todos</option>' + data.summary.tiempoProblemas.map((c) => option(c.label)).join('');

  const renderTable = () => {
    const filtered = filterProblems(data.problemas, controls);
    document.getElementById('problemas-table-body').innerHTML = filtered.map(makeProblemRow).join('');
    document.getElementById('problemas-count').textContent = filtered.length + ' problemas visibles';
  };

  Object.values(controls).forEach((el) => el.addEventListener('input', renderTable));
  renderTable();
}

function renderMerges(data) {
  const mergesHtml = data.merges.map((m) => {
    const links = m.problemasRelacionados
      .map((p) => '<a href="' + p.detailHtml + '">Fila ' + p.fila + ': ' + htmlEscape(p.shortName) + '</a>')
      .join('<br>');

    return '<article class="merge-card" id="' + htmlEscape(m.id) + '">' +
      '<h3><a href="' + m.detailHtml + '">' + htmlEscape(m.id + ' · ' + m.shortTitle) + '</a></h3>' +
      '<p class="small">Filas combinadas: ' + htmlEscape(m.filasCombinadas.join(', ')) + ' · Areas: ' + htmlEscape(m.areas.join(', ')) + '</p>' +
      '<p><strong>KAIZEN dominante:</strong> ' + htmlEscape(m.kaizenDominante) + '</p>' +
      '<p>' + colorPill(m.gravedad.label, m.gravedad.hex) + ' ' + colorPill(m.tiempo.label, m.tiempo.hex) + '</p>' +
      '<p><strong>Razon de consolidacion:</strong> mismo patron estructural y cuello de botella transversal descrito en el merge.</p>' +
      '<p><strong>Problemas vinculados:</strong><br>' + links + '</p>' +
    '</article>';
  }).join('');

  document.getElementById('merge-list').innerHTML = mergesHtml;
}

boot().catch((err) => {
  console.error(err);
  document.body.insertAdjacentHTML('beforeend', '<pre style="padding:1rem;color:#b00">Error cargando dashboard: ' + String(err) + '</pre>');
});`;
}

function createHomeHtml() {
  return `<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>PROTAB · Plataforma Kaizen</title>
  <link rel="stylesheet" href="assets/styles.css" />
</head>
<body data-page="home">
  <header>
    <div class="header-inner">
      <h1>PROTAB · Plataforma Kaizen</h1>
      <nav>
        <a data-nav="aprendizaje" href="aprendizaje-kaizen.html">Aprendizaje Kaizen</a>
        <a data-nav="dashboard" href="dashboard-kaizen.html">Dashboard Kaizen</a>
        <a data-nav="problemas" href="todos-los-problemas.html">Todos los problemas</a>
        <a data-nav="merges" href="merges.html">Merges</a>
      </nav>
    </div>
  </header>
  <main>
    <section class="card">
      <h2>Portal navegable del diagnostico Kaizen</h2>
      <p>Este sitio integra aprendizaje Kaizen, dashboard ejecutivo, navegacion por los 23 problemas y los 7 merges, y acceso directo a cada HTML exportado desde sus markdown originales.</p>
      <p><strong>Inicio recomendado:</strong> <a href="dashboard-kaizen.html">Dashboard Kaizen</a>.</p>
    </section>
  </main>
  <script src="assets/data.js"></script>
  <script src="assets/app.js"></script>
</body>
</html>`;
}

function createAprendizajeHtml() {
  return createBaseHtml({
    pageId: 'aprendizaje',
    pageTitle: 'Aprendizaje Kaizen · PROTAB',
    heading: 'Aprendizaje Kaizen',
    lead:
      'Pagina de aprendizaje para entender la categorizacion usada, su fundamento y la trazabilidad del analisis.',
    bodyMarkup: `
      <section id="aprendizaje-metricas" class="card"></section>

      <section class="card">
        <h3>Marco usado en este diagnostico</h3>
        <div class="flow">
          <div class="flow-step"><strong>1. Evidencia</strong><br/>Matriz + entrevistas + consolidado.</div>
          <div class="flow-step"><strong>2. Problema operacional</strong><br/>Se define cuello de botella, impacto y subproblemas.</div>
          <div class="flow-step"><strong>3. Clasificacion Kaizen</strong><br/>Se asigna desperdicio principal y secundario.</div>
          <div class="flow-step"><strong>4. Priorizacion</strong><br/>Importancia, IBO y semaforos por impacto y tiempo.</div>
        </div>
      </section>

      <section class="card">
        <h3>Glosario operativo Kaizen</h3>
        <p><strong>Muda:</strong> desperdicio que no agrega valor.</p>
        <p><strong>Mura:</strong> variabilidad del flujo que genera ineficiencia.</p>
        <p><strong>Muri:</strong> sobrecarga de personas/procesos/sistemas.</p>
      </section>

      <section class="card">
        <h3>Categorias Kaizen aplicadas</h3>
        <div id="kaizen-categorias" class="legend-list"></div>
      </section>

      <section class="grid two">
        <section class="card">
          <h3>Glosa de color por impacto/gravedad</h3>
          <div id="glosa-impacto" class="legend-list"></div>
        </section>
        <section class="card">
          <h3>Glosa de color por tiempo de implementacion</h3>
          <div id="glosa-tiempo" class="legend-list"></div>
        </section>
      </section>

      <section class="card">
        <h3>Origen del analisis</h3>
        <ul>
          <li>Trazabilidad fila a fila: <code>Trazabilidad_Filas_23.csv</code>.</li>
          <li>Resumen consolidado: <code>Resumen_KAIZEN_Consolidado.md</code>.</li>
          <li>Problemas individuales: <code>problemas_individuales/*.md</code>.</li>
          <li>Consolidaciones estructurales: <code>problemas_merged/*.md</code>.</li>
          <li>Glosa de color aplicada en dashboard: <code>Glosa_Mapa_Colores.md</code>.</li>
        </ul>
      </section>`,
  });
}

function createDashboardHtml() {
  return createBaseHtml({
    pageId: 'dashboard',
    pageTitle: 'Dashboard Kaizen · PROTAB',
    heading: 'Dashboard Kaizen',
    lead:
      'Panel ejecutivo con trazabilidad de problemas, glosa de colores y graficas por categoria, area, impacto y tiempo de implementacion.',
    bodyMarkup: `
      <section id="dash-kpis" class="card"></section>

      <section class="grid two">
        <div id="chart-kaizen"></div>
        <div id="chart-areas"></div>
      </section>

      <section class="grid two">
        <div id="chart-gravedad-prob"></div>
        <div id="chart-tiempo-prob"></div>
      </section>

      <section class="grid two">
        <div id="chart-gravedad-merge"></div>
        <div id="chart-tiempo-merge"></div>
      </section>

      <section class="grid two">
        <section class="card">
          <h3>Glosa color por impacto/gravedad (usada en dashboard)</h3>
          <div id="dashboard-glosa-impacto" class="legend-list"></div>
        </section>
        <section class="card">
          <h3>Glosa color por tiempo de implementacion (usada en dashboard)</h3>
          <div id="dashboard-glosa-tiempo" class="legend-list"></div>
        </section>
      </section>

      <section class="card">
        <h3>Filtro de problemas</h3>
        <div class="controls">
          <div><label for="f-search">Buscar</label><input id="f-search" type="search" placeholder="Nombre, area o categoria" /></div>
          <div><label for="f-area">Area</label><select id="f-area"></select></div>
          <div><label for="f-kaizen">Categoria Kaizen</label><select id="f-kaizen"></select></div>
          <div><label for="f-importancia">Importancia</label><select id="f-importancia"></select></div>
          <div><label for="f-merge">Merge</label><select id="f-merge"><option value="">Todos</option><option value="con">Con merge</option><option value="sin">Sin merge</option></select></div>
          <div><label for="f-gravedad">Color impacto</label><select id="f-gravedad"></select></div>
          <div><label for="f-tiempo">Color tiempo</label><select id="f-tiempo"></select></div>
        </div>
        <p id="resultado-filtro" class="small"></p>
        <table>
          <thead>
            <tr>
              <th>Problema</th>
              <th>Area</th>
              <th>KAIZEN</th>
              <th>Importancia</th>
              <th>Color impacto</th>
              <th>Color tiempo</th>
              <th>Merge</th>
            </tr>
          </thead>
          <tbody id="tabla-problemas"></tbody>
        </table>
      </section>`,
  });
}

function createProblemasHtml() {
  return createBaseHtml({
    pageId: 'problemas',
    pageTitle: 'Todos los problemas · PROTAB',
    heading: 'Todos los problemas',
    lead:
      'Listado completo de 23 problemas con filtros y acceso a su HTML exportado individual.',
    bodyMarkup: `
      <section class="card">
        <div class="controls">
          <div><label for="p-search">Buscar</label><input id="p-search" type="search" placeholder="Nombre, area o categoria" /></div>
          <div><label for="p-area">Area</label><select id="p-area"></select></div>
          <div><label for="p-kaizen">Categoria Kaizen</label><select id="p-kaizen"></select></div>
          <div><label for="p-importancia">Importancia</label><select id="p-importancia"></select></div>
          <div><label for="p-merge">Merge</label><select id="p-merge"><option value="">Todos</option><option value="con">Con merge</option><option value="sin">Sin merge</option></select></div>
          <div><label for="p-gravedad">Color impacto</label><select id="p-gravedad"></select></div>
          <div><label for="p-tiempo">Color tiempo</label><select id="p-tiempo"></select></div>
        </div>
        <p id="problemas-count" class="small"></p>
        <table>
          <thead>
            <tr>
              <th>Problema (nombre corto)</th>
              <th>Area</th>
              <th>KAIZEN principal</th>
              <th>Importancia</th>
              <th>Color impacto</th>
              <th>Color tiempo</th>
              <th>Merge asociado</th>
            </tr>
          </thead>
          <tbody id="problemas-table-body"></tbody>
        </table>
      </section>`,
  });
}

function createMergesHtml() {
  return createBaseHtml({
    pageId: 'merges',
    pageTitle: 'Merges · PROTAB',
    heading: 'Merges',
    lead:
      'Consolidaciones de problemas equivalentes: que filas combina cada merge, por que se consolidan y como se clasifican.',
    bodyMarkup: `
      <section class="card">
        <p>Esta seccion usa los archivos merge para explicar que problemas representan el mismo patron estructural y su categorizacion Kaizen.</p>
      </section>
      <section id="merge-list" class="card-list"></section>`,
  });
}

function parseGlosa(glosaText) {
  const gravedadMatch = glosaText.match(/##\s*1\)[\s\S]*?(?=\n##\s*2\)|$)/i);
  const tiempoMatch = glosaText.match(/##\s*2\)[\s\S]*?(?=\n##\s*Nota|$)/i);
  const gravedadSection = gravedadMatch ? gravedadMatch[0] : '';
  const tiempoSection = tiempoMatch ? tiempoMatch[0] : '';

  const gravedad = gravedadSection
    .split(/\r?\n/)
    .filter((line) => line.trim().startsWith('- '))
    .map((line) => {
      const match = line.match(/-\s*([^:]+):\s*\*\*([^()]+)\((#[0-9A-Fa-f]{6})\)\*\*\s*->\s*(.+)$/);
      if (!match) {
        return {
          label: line.replace(/^-\s*/, '').trim(),
          hex: '#9AA5B1',
          description: '',
        };
      }
      return {
        label: `${match[1].trim()} · ${match[2].trim()}`,
        hex: match[3].toUpperCase(),
        description: match[4].trim(),
      };
    });

  const tiempo = tiempoSection
    .split(/\r?\n/)
    .filter((line) => line.trim().startsWith('- '))
    .map((line) => {
      const match = line.match(/-\s*\*\*([^()]+)\((#[0-9A-Fa-f]{6})\)\*\*:\s*(.+)$/);
      if (!match) {
        return {
          label: line.replace(/^-\s*/, '').trim(),
          hex: '#9AA5B1',
          description: '',
        };
      }
      return {
        label: match[1].trim(),
        hex: match[2].toUpperCase(),
        description: match[3].trim(),
      };
    });

  return { gravedad, tiempo };
}

function main() {
  const csvRows = parseCsvRows(readText(paths.trazabilidadCsv));
  const glosa = parseGlosa(readText(paths.glosaMd));

  fs.rmSync(paths.outputDir, { recursive: true, force: true });
  safeMkdir(paths.outAssetsDir);
  safeMkdir(paths.outDetailProblemasDir);
  safeMkdir(paths.outDetailMergesDir);

  const problemas = csvRows
    .slice()
    .sort((a, b) => a.fila - b.fila)
    .map((row) => {
      const mdPath = path.join(paths.problemasDir, row.documento_individual);
      if (!fs.existsSync(mdPath)) {
        throw new Error(`No existe archivo individual: ${row.documento_individual}`);
      }
      const markdown = readText(mdPath);
      const title = extractHeadingLevel1(markdown);

      const gravedadSection = extractSection(markdown, 'Semaforo De Gravedad') || extractSection(markdown, 'Semáforo De Gravedad');
      const tiempoSection =
        extractSection(markdown, 'Semaforo De Tiempo De Implementacion Tentativa') ||
        extractSection(markdown, 'Semáforo De Tiempo De Implementación Tentativa') ||
        extractSection(markdown, 'Semáforo De Tiempo De Implementación Tentativa');

      const gravedadToken = extractValue(gravedadSection, /-\s*Color asignado:\s*\*\*(.*?)\*\*/);
      const tiempoToken = extractValue(tiempoSection, /-\s*Color asignado:\s*\*\*(.*?)\*\*/);

      const gravedad = parseColorToken(gravedadToken);
      const tiempo = parseColorToken(tiempoToken);

      const detailFile = `fila-${row.fila}.html`;
      const detailPath = path.join(paths.outDetailProblemasDir, detailFile);
      runQuartoPandoc(mdPath, detailPath);

      return {
        id: `fila-${row.fila}`,
        fila: row.fila,
        title,
        shortName: sanitizeShortName(row.problema),
        area: row.area,
        kaizen: row.kaizen,
        importancia: row.importancia,
        mergeId: row.merged_ids || '',
        gravedad,
        tiempo,
        sourceMd: `problemas_individuales/${row.documento_individual}`,
        detailHtml: `detalle/problemas/${detailFile}`,
      };
    });

  const mergeFiles = sortedFiles(paths.mergesDir);
  const merges = mergeFiles.map((fileName) => {
    const mdPath = path.join(paths.mergesDir, fileName);
    const markdown = readText(mdPath);
    const title = extractHeadingLevel1(markdown);
    const idMatch = fileName.match(/^(M\d+)/i);
    if (!idMatch) {
      throw new Error(`Nombre de merge invalido: ${fileName}`);
    }
    const id = idMatch[1].toUpperCase();

    const gravedadSection = extractSection(markdown, 'Semaforo De Gravedad') || extractSection(markdown, 'Semáforo De Gravedad');
    const tiempoSection =
      extractSection(markdown, 'Semaforo De Tiempo De Implementacion Tentativa') ||
      extractSection(markdown, 'Semáforo De Tiempo De Implementación Tentativa') ||
      extractSection(markdown, 'Semáforo De Tiempo De Implementación Tentativa');

    const gravedad = parseColorToken(extractValue(gravedadSection, /-\s*Color asignado:\s*\*\*(.*?)\*\*/));
    const tiempo = parseColorToken(extractValue(tiempoSection, /-\s*Color asignado:\s*\*\*(.*?)\*\*/));

    const filasCombinadasRaw = extractValue(markdown, /-\s*Filas combinadas:\s*(.+)/);
    const filasCombinadas = filasCombinadasRaw
      .split(',')
      .map((v) => Number(v.trim()))
      .filter((n) => Number.isFinite(n));

    const areasRaw = extractValue(markdown, /-\s*Areas involucradas:\s*(.+)/) || extractValue(markdown, /-\s*Áreas involucradas:\s*(.+)/);
    const areas = areasRaw
      .split(',')
      .map((v) => v.trim())
      .filter(Boolean);

    const kaizenDominante =
      extractValue(markdown, /-\s*KAIZEN dominante:\s*(.+)/) ||
      extractValue(markdown, /-\s*KAIZEN dominante:\s*\*\*(.+?)\*\*/);

    const importanciaPromedio = Number(extractValue(markdown, /-\s*Importancia promedio:\s*([0-9.]+)\/5/)) || 0;

    const detailFile = `${id}.html`;
    const detailPath = path.join(paths.outDetailMergesDir, detailFile);
    runQuartoPandoc(mdPath, detailPath);

    const related = problemas
      .filter((p) => p.mergeId === id)
      .map((p) => ({ fila: p.fila, shortName: p.shortName, detailHtml: p.detailHtml }));

    return {
      id,
      title,
      shortTitle: title.replace(/^Fila\s+.+?-\s+/i, '').trim(),
      filasCombinadas,
      areas,
      kaizenDominante,
      importanciaPromedio,
      gravedad,
      tiempo,
      sourceMd: `problemas_merged/${fileName}`,
      detailHtml: `detalle/merges/${detailFile}`,
      problemasRelacionados: related,
    };
  });

  if (problemas.length !== EXPECTED.totalProblemas) {
    throw new Error(`Esperados ${EXPECTED.totalProblemas} problemas y se encontraron ${problemas.length}`);
  }

  if (merges.length !== EXPECTED.totalMerges) {
    throw new Error(`Esperados ${EXPECTED.totalMerges} merges y se encontraron ${merges.length}`);
  }

  const kaizenActual = toCountMap(problemas, (p) => p.kaizen);
  const areaActual = toCountMap(problemas, (p) => p.area);

  compareExpectedMap(kaizenActual, EXPECTED.kaizen, 'conteo KAIZEN');
  compareExpectedMap(areaActual, EXPECTED.areas, 'conteo areas');

  const importanciaPromedio =
    problemas.reduce((acc, p) => acc + p.importancia, 0) / (problemas.length || 1);

  const summary = {
    totalProblemas: problemas.length,
    totalMerges: merges.length,
    importanciaPromedio,
    kaizenCounts: Object.entries(kaizenActual)
      .map(([label, value]) => ({ label, value, color: '#1f7a8c' }))
      .sort((a, b) => b.value - a.value),
    areaCounts: Object.entries(areaActual)
      .map(([label, value]) => ({ label, value, color: '#5a9f68' }))
      .sort((a, b) => b.value - a.value),
    gravedadProblemas: Object.values(
      problemas.reduce((acc, p) => {
        const key = `${p.gravedad.label}::${p.gravedad.hex}`;
        if (!acc[key]) acc[key] = { label: p.gravedad.label, color: p.gravedad.hex, value: 0 };
        acc[key].value += 1;
        return acc;
      }, {})
    ).sort((a, b) => b.value - a.value),
    tiempoProblemas: Object.values(
      problemas.reduce((acc, p) => {
        const key = `${p.tiempo.label}::${p.tiempo.hex}`;
        if (!acc[key]) acc[key] = { label: p.tiempo.label, color: p.tiempo.hex, value: 0 };
        acc[key].value += 1;
        return acc;
      }, {})
    ).sort((a, b) => b.value - a.value),
    gravedadMerges: Object.values(
      merges.reduce((acc, m) => {
        const key = `${m.gravedad.label}::${m.gravedad.hex}`;
        if (!acc[key]) acc[key] = { label: m.gravedad.label, color: m.gravedad.hex, value: 0 };
        acc[key].value += 1;
        return acc;
      }, {})
    ).sort((a, b) => b.value - a.value),
    tiempoMerges: Object.values(
      merges.reduce((acc, m) => {
        const key = `${m.tiempo.label}::${m.tiempo.hex}`;
        if (!acc[key]) acc[key] = { label: m.tiempo.label, color: m.tiempo.hex, value: 0 };
        acc[key].value += 1;
        return acc;
      }, {})
    ).sort((a, b) => b.value - a.value),
  };

  const dataset = {
    generatedAt: new Date().toISOString(),
    summary,
    glosa,
    problemas,
    merges,
    sources: {
      resumenMd: path.basename(paths.resumenMd),
      trazabilidadCsv: path.basename(paths.trazabilidadCsv),
      glosaMd: path.basename(paths.glosaMd),
    },
  };

  fs.writeFileSync(
    path.join(paths.outAssetsDir, 'data.json'),
    JSON.stringify(dataset, null, 2),
    'utf8'
  );
  fs.writeFileSync(
    path.join(paths.outAssetsDir, 'data.js'),
    `window.KAIZEN_DATA = ${JSON.stringify(dataset)};`,
    'utf8'
  );

  fs.writeFileSync(path.join(paths.outAssetsDir, 'styles.css'), createSiteStyles(), 'utf8');
  fs.writeFileSync(path.join(paths.outAssetsDir, 'app.js'), buildAppJs(), 'utf8');

  fs.writeFileSync(path.join(paths.outputDir, 'index.html'), createHomeHtml(), 'utf8');
  fs.writeFileSync(path.join(paths.outputDir, 'aprendizaje-kaizen.html'), createAprendizajeHtml(), 'utf8');
  fs.writeFileSync(path.join(paths.outputDir, 'dashboard-kaizen.html'), createDashboardHtml(), 'utf8');
  fs.writeFileSync(path.join(paths.outputDir, 'todos-los-problemas.html'), createProblemasHtml(), 'utf8');
  fs.writeFileSync(path.join(paths.outputDir, 'merges.html'), createMergesHtml(), 'utf8');

  const readme = `# Kaizen Web\n\nSitio estatico generado desde los markdown y el CSV del diagnostico Kaizen.\n\n## Generar\n\n\`\`\`bash\nnode scripts/build_kaizen_web.mjs\n\`\`\`\n\n## Abrir\n\nAbrir \`kaizen_web/index.html\` en navegador.\n\n## Contenido\n\n- \`kaizen_web/aprendizaje-kaizen.html\`\n- \`kaizen_web/dashboard-kaizen.html\`\n- \`kaizen_web/todos-los-problemas.html\`\n- \`kaizen_web/merges.html\`\n- \`kaizen_web/detalle/problemas/*.html\` (23 exportados)\n- \`kaizen_web/detalle/merges/*.html\` (7 exportados)\n`;

  fs.writeFileSync(path.join(paths.outputDir, 'README.md'), readme, 'utf8');

  console.log('Build completado en:', paths.outputDir);
  console.log('Problemas:', problemas.length, '| Merges:', merges.length);
}

main();
